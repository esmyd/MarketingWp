<?php

namespace App\Http\Controllers;

use App\Models\WhatsappCart;
use App\Models\WhatsappMessage;
use App\Models\WhatsappContact;
use App\Models\WhatsappConversation;
use Illuminate\Http\Request;

class AdminController extends Controller
{
    public function dashboard()
    {
        $orders = WhatsappCart::with(['items', 'contact'])->latest()->get();
        $messages = WhatsappMessage::with(['contact', 'conversation'])->latest()->get();

        return view('admin.dashboard', compact('orders', 'messages'));
    }

    public function orders()
    {
        $orders = WhatsappCart::with(['items', 'contact'])
            ->latest()
            ->paginate(10);

        return view('admin.orders', compact('orders'));
    }

    public function messages()
    {
        $messages = WhatsappMessage::with(['contact', 'conversation'])
            ->latest()
            ->paginate(20);

        return view('admin.messages', compact('messages'));
    }

    public function orderDetails($id)
    {
        $order = WhatsappCart::with(['items', 'contact'])->findOrFail($id);
        return response()->json($order);
    }

    public function chats()
    {
        // Obtener contactos que tengan mensajes usando consultas directas
        $contacts = \App\Models\WhatsappContact::whereIn('id', function($query) {
            $query->select('contact_id')->from('whatsapp_messages')->distinct();
        })->get();
        // Contar mensajes por contacto
        foreach ($contacts as $contact) {
            $contact->messages_count = \App\Models\WhatsappMessage::where('contact_id', $contact->id)->count();
        }
        return view('admin.chats', compact('contacts'));
    }

    public function chat($contactId)
    {
        $contact = \App\Models\WhatsappContact::findOrFail($contactId);
        $messages = \App\Models\WhatsappMessage::where('contact_id', $contactId)->orderBy('created_at')->get();
        return view('admin.chat', compact('contact', 'messages'));
    }
}
