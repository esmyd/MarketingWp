<?php $__env->startSection('header', 'Pedidos'); ?>

<?php $__env->startSection('content'); ?>
<div class="bg-white shadow-sm rounded-lg overflow-hidden">
    <div class="p-6">
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Cliente</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Fecha</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Estado</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Total</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Acciones</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="text-sm font-medium text-gray-900">
                                    <?php echo e($order->contact->name ?? 'Cliente'); ?>

                                </div>
                                <div class="text-sm text-gray-500">
                                    <?php echo e($order->contact->phone ?? 'Sin teléfono'); ?>

                                </div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                <?php echo e($order->created_at->format('d/m/Y H:i')); ?>

                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <span class="px-3 py-1 rounded-full text-sm <?php echo e($order->status === 'completed' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'); ?>">
                                    <?php echo e($order->status); ?>

                                </span>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                $<?php echo e(number_format($order->total, 2)); ?>

                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                <button class="text-blue-600 hover:text-blue-900" onclick="showOrderDetails(<?php echo e($order->id); ?>)">
                                    Ver detalles
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="px-6 py-4 text-center text-gray-500">
                                No hay pedidos registrados
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="mt-4">
            <?php echo e($orders->links()); ?>

        </div>
    </div>
</div>

<!-- Modal para detalles del pedido -->
<div id="orderModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden overflow-y-auto h-full w-full z-50">
    <div class="relative top-20 mx-auto p-5 border w-full max-w-lg shadow-lg rounded-md bg-white">
        <div class="mt-3">
            <h3 class="text-lg font-medium leading-6 text-gray-900">Detalles del Pedido</h3>
            <div id="orderDetails" class="mt-2 text-sm text-gray-700">
                <div class="flex justify-center items-center h-24" id="orderLoading">
                    <span class="text-gray-400">Cargando...</span>
                </div>
            </div>
            <div class="mt-4">
                <button onclick="closeOrderModal()" class="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-blue-600 text-base font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 sm:text-sm">
                    Cerrar
                </button>
            </div>
        </div>
    </div>
</div>

<script>
function showOrderDetails(orderId) {
    document.getElementById('orderModal').classList.remove('hidden');
    const detailsDiv = document.getElementById('orderDetails');
    detailsDiv.innerHTML = '<div class="flex justify-center items-center h-24" id="orderLoading"><span class="text-gray-400">Cargando...</span></div>';
    fetch(`/admin/orders/${orderId}/details`)
        .then(res => res.json())
        .then(order => {
            let html = '';
            html += `<div class='mb-2'><b>Cliente:</b> ${order.contact?.name ?? 'Cliente'}<br>`;
            html += `<b>Teléfono:</b> ${order.contact?.phone_number ?? 'Sin teléfono'}<br>`;
            html += `<b>Estado:</b> <span class='px-2 py-1 rounded bg-gray-100'>${order.status}</span><br>`;
            html += `<b>Total:</b> $${parseFloat(order.total).toFixed(2)}<br>`;
            html += `<b>Fecha:</b> ${new Date(order.created_at).toLocaleString('es-ES')}<br></div>`;
            if(order.items && order.items.length > 0) {
                html += `<table class='w-full text-xs mb-2'><thead><tr><th class='text-left'>Producto</th><th>Cant.</th><th>Precio</th></tr></thead><tbody>`;
                order.items.forEach(item => {
                    html += `<tr><td>${item.name}</td><td class='text-center'>${item.quantity}</td><td class='text-right'>$${parseFloat(item.price).toFixed(2)}</td></tr>`;
                });
                html += `</tbody></table>`;
            } else {
                html += `<div class='text-gray-400'>Sin productos</div>`;
            }
            detailsDiv.innerHTML = html;
        })
        .catch(() => {
            detailsDiv.innerHTML = '<div class="text-red-500">No se pudo cargar el detalle.</div>';
        });
}

function closeOrderModal() {
    document.getElementById('orderModal').classList.add('hidden');
}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programas\Laragon\laragon\www\WhatsApp\MarketingWp\resources\views/admin/orders.blade.php ENDPATH**/ ?>