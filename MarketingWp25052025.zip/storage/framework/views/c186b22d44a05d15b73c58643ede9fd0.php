<?php $__env->startSection('header', 'Chats de Clientes'); ?>

<?php $__env->startSection('content'); ?>
<div class="bg-white shadow-sm rounded-lg overflow-hidden">
    <div class="p-6">
        <h2 class="text-xl font-semibold mb-4">Clientes con Conversaciones</h2>
        <ul class="divide-y divide-gray-200">
            <?php $__empty_1 = true; $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <li>
                    <a href="<?php echo e(route('admin.chat', $contact->id)); ?>" class="flex items-center py-4 hover:bg-gray-50 transition">
                        <div class="flex-1">
                            <span class="font-medium text-gray-900"><?php echo e($contact->name ?? 'Cliente'); ?></span>
                            <span class="ml-2 text-xs text-gray-500"><?php echo e($contact->phone_number); ?></span>
                        </div>
                        <span class="text-xs text-gray-400"><?php echo e($contact->messages_count); ?> mensajes</span>
                        <i class="fas fa-chevron-right ml-4 text-gray-300"></i>
                    </a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <li class="py-8 text-center text-gray-400">No hay chats disponibles</li>
            <?php endif; ?>
        </ul>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programas\Laragon\laragon\www\WhatsApp\MarketingWp\resources\views/admin/chats.blade.php ENDPATH**/ ?>