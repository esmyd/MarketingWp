<?php $__env->startSection('header', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="grid grid-cols-1 md:grid-cols-2 gap-6">
    <!-- Orders Summary -->
    <div class="bg-white overflow-hidden shadow-sm rounded-lg">
        <div class="p-6">
            <h2 class="text-xl font-semibold mb-4">Últimos Pedidos</h2>
            <div class="space-y-4">
                <?php $__empty_1 = true; $__currentLoopData = $orders->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="border-b pb-4">
                        <div class="flex justify-between items-center">
                            <div>
                                <p class="font-medium"><?php echo e($order->contact->name ?? 'Cliente'); ?></p>
                                <p class="text-sm text-gray-600"><?php echo e($order->created_at->format('d/m/Y H:i')); ?></p>
                            </div>
                            <span class="px-3 py-1 rounded-full text-sm <?php echo e($order->status === 'completed' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'); ?>">
                                <?php echo e($order->status); ?>

                            </span>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-gray-500">No hay pedidos recientes</p>
                <?php endif; ?>
            </div>
            <a href="<?php echo e(route('admin.orders')); ?>" class="mt-4 inline-block text-blue-600 hover:text-blue-800">Ver todos los pedidos →</a>
        </div>
    </div>

    <!-- Messages Summary -->
    <div class="bg-white overflow-hidden shadow-sm rounded-lg">
        <div class="p-6">
            <h2 class="text-xl font-semibold mb-4">Últimos Mensajes</h2>
            <div class="space-y-4">
                <?php $__empty_1 = true; $__currentLoopData = $messages->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="border-b pb-4">
                        <div class="flex justify-between items-center">
                            <div>
                                <p class="font-medium"><?php echo e($message->contact->name ?? 'Cliente'); ?></p>
                                <?php
                                    $content = $message->content;
                                    $decoded = null;
                                    try {
                                        $decoded = json_decode($content, true, 512, JSON_THROW_ON_ERROR);
                                    } catch (\Throwable $e) {
                                        $decoded = null;
                                    }
                                ?>
                                <?php if(is_array($decoded) && isset($decoded['title'])): ?>
                                    <p class="text-sm text-gray-800 font-semibold"><?php echo e($decoded['title']); ?></p>
                                    <?php if(isset($decoded['description'])): ?>
                                        <p class="text-xs text-gray-600"><?php echo e(\Illuminate\Support\Str::limit($decoded['description'], 80)); ?></p>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <p class="text-sm text-gray-600 truncate max-w-md"><?php echo e(\Illuminate\Support\Str::limit($content, 80)); ?></p>
                                <?php endif; ?>
                                <p class="text-xs text-gray-500"><?php echo e($message->created_at->format('d/m/Y H:i')); ?></p>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-gray-500">No hay mensajes recientes</p>
                <?php endif; ?>
            </div>
            <a href="<?php echo e(route('admin.messages')); ?>" class="mt-4 inline-block text-blue-600 hover:text-blue-800">Ver todos los mensajes →</a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programas\Laragon\laragon\www\WhatsApp\MarketingWp\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>