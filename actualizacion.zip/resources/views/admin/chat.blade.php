@extends('admin.layouts.app')

@section('header')
@endsection

@section('content')
<style>
    body {
        background: linear-gradient(135deg, #d2dbdc 0%, #ece5dd 100%) !important;
    }
    .wa-bubble-in {
        background: #f1f0f0;
        color: #222;
        border-radius: 1.1em 1.1em 1.1em 0.4em;
        box-shadow: 0 1px 2px rgba(0,0,0,0.04);
        border: 1px solid #e5e7eb;
    }
    .wa-bubble-out {
        background: #d1f7c4;
        color: #222;
        border-radius: 1.1em 1.1em 0.4em 1.1em;
        box-shadow: 0 1px 2px rgba(0,0,0,0.04);
        border: 1px solid #b6e6a7;
    }
    .wa-btn-reply {
        display: inline-block;
        background: #25d366;
        color: #fff;
        font-weight: 500;
        border-radius: 0.7em;
        padding: 0.3em 1em;
        margin-top: 0.2em;
        margin-bottom: 0.2em;
        font-size: 0.97em;
        box-shadow: 0 1px 2px rgba(0,0,0,0.04);
        border: none;
        cursor: pointer;
        white-space: pre-line;
    }
    .wa-badge {
        display: inline-flex;
        align-items: center;
        gap: 0.3em;
        padding: 0.1em 0.6em;
        border-radius: 9999px;
        font-size: 0.75em;
        font-weight: 600;
        margin-bottom: 0.3em;
    }
    .wa-badge-cliente {
        background: #d1fae5;
        color: #047857;
    }
    .wa-badge-sistema {
        background: #dbeafe;
        color: #1d4ed8;
    }
    .wa-bubble-content {
        word-break: break-word;
        overflow-wrap: break-word;
        white-space: pre-line;
    }
    .wa-main-bg {
        min-height: 100vh;
        background: linear-gradient(135deg, #d2dbdc 0%, #ece5dd 100%);
        display: flex;
        justify-content: center;
        align-items: flex-start;
        padding-top: 0;
    }
    .wa-card {
        width: 100%;
        max-width: 1100px;
        height: 80vh;
        background: #fff;
        border-radius: 1.2em;
        box-shadow: 0 8px 32px 0 rgba(31,38,135,0.15);
        display: flex;
        overflow: hidden;
        border: 1px solid #e5e7eb;
    }
    .wa-sidebar {
        background: #f7fafc;
        border-right: 1px solid #e5e7eb;
        min-width: 320px;
        max-width: 350px;
        height: 80vh;
        overflow-y: auto;
    }
    .wa-sidebar-contact {
        display: flex;
        align-items: center;
        gap: 0.8em;
        padding: 1em 1.2em;
        border-bottom: 1px solid #f1f1f1;
        cursor: pointer;
        transition: background 0.2s;
        text-decoration: none;
        color: inherit;
    }
    .wa-sidebar-contact.active, .wa-sidebar-contact:hover {
        background: #e0f2fe;
    }
    .wa-sidebar-avatar {
        width: 2.5em;
        height: 2.5em;
        border-radius: 9999px;
        background: #bbf7d0;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: bold;
        color: #047857;
        font-size: 1.1em;
    }
    .wa-sidebar-name {
        font-weight: 600;
        font-size: 1em;
        color: #222;
    }
    .wa-sidebar-phone {
        font-size: 0.85em;
        color: #888;
    }
</style>
<div class="wa-main-bg">
    <div class="wa-card">
        <!-- Sidebar -->
        <div class="wa-sidebar">
            <div class="p-4 pb-2 font-bold text-lg text-green-700 border-b">Chats</div>
            @foreach($contacts as $c)
                <a href="{{ route('admin.chat', $c->id) }}" class="wa-sidebar-contact{{ $contact->id === $c->id ? ' active' : '' }}">
                    <div class="wa-sidebar-avatar">{{ strtoupper(mb_substr($c->name ?? 'C', 0, 1)) }}</div>
                    <div>
                        <div class="wa-sidebar-name">{{ $c->name ?? 'Cliente' }}</div>
                        <div class="flex items-center justify-between wa-sidebar-phone">
                            <span>{{ $c->phone_number }}</span>
                            @if(isset($c->messages_count) && $c->messages_count > 0)
                                <span class="text-xs text-gray-400 font-semibold ml-2">{{ $c->messages_count }}</span>
                            @endif
                        </div>
                        @if(!empty($c->last_client_message))
                            <div class="text-xs text-gray-500 mt-0.5 truncate max-w-[180px]">
                                {{ \Illuminate\Support\Str::limit(strip_tags($c->last_client_message), 40) }}
                            </div>
                        @endif
                    </div>
                </a>
            @endforeach
        </div>
        <!-- Chat Panel -->
        <div class="flex-1 flex flex-col">
            <!-- Header pegado arriba -->
            <div class="flex items-center gap-3 px-6 py-4 border-b bg-gray-50" style="min-height:64px;">
                <div class="w-10 h-10 rounded-full bg-green-200 flex items-center justify-center text-lg font-bold text-green-700">
                    {{ strtoupper(mb_substr($contact->name ?? 'C', 0, 1)) }}
                </div>
                <div>
                    <div class="font-semibold">{{ $contact->name ?? 'Cliente' }}</div>
                    <div class="text-xs text-gray-400">{{ $contact->phone_number }}</div>
                </div>
            </div>
            <!-- Mensajes -->
            <div class="flex-1 overflow-y-auto p-6 space-y-2 bg-gray-100" id="chat-messages" style="scroll-behavior: smooth;">
                @forelse($messages as $msg)
                    @php
                        $isIncoming = $msg->sender_type === 'client';
                        $bubbleClass = $isIncoming ? 'wa-bubble-in' : 'wa-bubble-out';
                        $align = $isIncoming ? 'justify-start' : 'justify-end';
                        $content = $msg->content;
                        $decoded = null;
                        try {
                            $decoded = json_decode($content, true, 512, JSON_THROW_ON_ERROR);
                        } catch (\Throwable $e) {
                            $decoded = null;
                        }
                    @endphp
                    <div class="flex {{ $align }}">
                        <div class="max-w-[70%] w-full break-words overflow-x-auto px-4 py-2 mb-1 {{ $bubbleClass }} relative">
                            @if($isIncoming)
                                <div class="wa-badge wa-badge-cliente"><span>👤</span>Cliente</div>
                            @else
                                <div class="wa-badge wa-badge-sistema"><span>🤖</span>Sistema</div>
                            @endif
                            @if(is_array($decoded) && isset($decoded['type']) && $decoded['type'] === 'button_reply' && isset($decoded['button_reply']['title']))
                                <span class="wa-btn-reply wa-bubble-content">{{ $decoded['button_reply']['title'] }}</span>
                                @if(isset($decoded['button_reply']['description']))
                                    <div class="text-xs text-gray-600 mb-1 wa-bubble-content">{{ \Illuminate\Support\Str::limit($decoded['button_reply']['description'], 120) }}</div>
                                @endif
                            @elseif(is_array($decoded) && isset($decoded['type']) && $decoded['type'] === 'list_reply' && isset($decoded['list_reply']['title']))
                                <div class="font-semibold mb-1 wa-bubble-content">{{ $decoded['list_reply']['title'] }}</div>
                                @if(isset($decoded['list_reply']['description']))
                                    <div class="text-xs text-gray-600 mb-1 wa-bubble-content">{{ \Illuminate\Support\Str::limit($decoded['list_reply']['description'], 120) }}</div>
                                @endif
                            @elseif(is_array($decoded) && isset($decoded['title']))
                                <div class="font-semibold mb-1 wa-bubble-content">{{ $decoded['title'] }}</div>
                                @if(isset($decoded['description']))
                                    <div class="text-xs text-gray-600 mb-1 wa-bubble-content">{{ \Illuminate\Support\Str::limit($decoded['description'], 120) }}</div>
                                @endif
                            @else
                                <span class="wa-bubble-content break-all">{{ $content }}</span>
                            @endif
                            <div class="text-[10px] text-gray-400 text-right mt-1">{{ $msg->created_at->format('d/m/Y H:i') }}</div>
                        </div>
                    </div>
                @empty
                    <div class="text-center text-gray-400">No hay mensajes en este chat</div>
                @endforelse
            </div>
        </div>
    </div>
</div>
<script>
    // Scroll automático al último mensaje
    window.onload = function() {
        var chat = document.getElementById('chat-messages');
        if(chat) chat.scrollTop = chat.scrollHeight;
    };

    // Scroll infinito (cargar más mensajes al llegar arriba)
    document.addEventListener('DOMContentLoaded', function() {
        var chat = document.getElementById('chat-messages');
        if(chat) {
            chat.addEventListener('scroll', function() {
                if(chat.scrollTop === 0) {
                    // Aquí puedes hacer una petición AJAX para cargar más mensajes
                    // y agregarlos al principio del contenedor
                }
            });
        }
    });
</script>
@endsection
