<?php $__env->startSection('header', 'Mensajes'); ?>

<?php $__env->startSection('content'); ?>
<div class="bg-white shadow-sm rounded-lg overflow-hidden">
    <div class="p-6">
        <div class="space-y-4">
            <?php $__empty_1 = true; $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="border rounded-lg p-4 hover:bg-gray-50">
                    <div class="flex justify-between items-start">
                        <div class="flex-1">
                            <div class="flex items-center space-x-2">
                                <span class="font-medium text-gray-900">
                                    <?php echo e($message->contact->name ?? 'Cliente'); ?>

                                </span>
                                <span class="text-sm text-gray-500">
                                    <?php echo e($message->contact->phone ?? 'Sin teléfono'); ?>

                                </span>
                            </div>
                            <p class="mt-2 text-gray-600">
                                <?php
                                    $content = $message->content;
                                    $decoded = null;
                                    try {
                                        $decoded = json_decode($content, true, 512, JSON_THROW_ON_ERROR);
                                    } catch (\Throwable $e) {
                                        $decoded = null;
                                    }
                                ?>
                                <?php if(is_array($decoded) && isset($decoded['title'])): ?>
                                    <span class="font-semibold"><?php echo e($decoded['title']); ?></span>
                                    <?php if(isset($decoded['description'])): ?>
                                        <br><span class="text-xs"><?php echo e(\Illuminate\Support\Str::limit($decoded['description'], 80)); ?></span>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <?php echo e(\Illuminate\Support\Str::limit($content, 80)); ?>

                                <?php endif; ?>
                            </p>
                            <div class="mt-2 flex items-center space-x-4 text-sm text-gray-500">
                                <span>
                                    <i class="far fa-clock mr-1"></i>
                                    <?php echo e($message->created_at->format('d/m/Y H:i')); ?>

                                </span>
                                <?php if($message->conversation): ?>
                                    <span>
                                        <i class="fas fa-comments mr-1"></i>
                                        Conversación #<?php echo e($message->conversation->id); ?>

                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="flex items-center space-x-2">
                            <?php if($message->type === 'incoming'): ?>
                                <span class="px-2 py-1 text-xs rounded-full bg-green-100 text-green-800">
                                    Recibido
                                </span>
                            <?php else: ?>
                                <span class="px-2 py-1 text-xs rounded-full bg-blue-100 text-blue-800">
                                    Enviado
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="text-center py-8 text-gray-500">
                    No hay mensajes registrados
                </div>
            <?php endif; ?>
        </div>

        <div class="mt-4">
            <?php echo e($messages->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programas\Laragon\laragon\www\WhatsApp\MarketingWp\resources\views/admin/messages.blade.php ENDPATH**/ ?>