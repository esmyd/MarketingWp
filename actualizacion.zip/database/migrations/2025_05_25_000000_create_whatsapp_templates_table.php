<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::create('whatsapp_templates', function (Blueprint $table) {
            $table->id();
            $table->string('template_id')->unique();
            $table->string('name');
            $table->string('category');
            $table->text('content')->nullable();
            $table->string('language');
            $table->string('status');
            $table->json('variables')->nullable();
            $table->json('components')->nullable();
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('whatsapp_templates');
    }
};
