<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::create('whatsapp_menu_configs', function (Blueprint $table) {
            $table->id();
            $table->foreignId('business_profile_id')->constrained('whatsapp_business_profiles')->onDelete('cascade');
            $table->boolean('enable_products')->default(true);
            $table->boolean('enable_services')->default(true);
            $table->boolean('enable_orders')->default(true);
            $table->boolean('enable_info')->default(true);
            $table->json('custom_menu_items')->nullable();
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('whatsapp_menu_configs');
    }
};
