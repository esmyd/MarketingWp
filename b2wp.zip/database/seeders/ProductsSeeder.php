<?php

namespace Database\Seeders;

use App\Models\Product;
use Illuminate\Database\Seeder;

class ProductsSeeder extends Seeder
{
    public function run()
    {
        $products = [
            [
                'name' => 'Batido F1 Sabor Vainilla',
                'description' => 'Batido nutricional con proteína de soya, vitaminas y minerales. Ideal para el control de peso.',
                'price' => 899.00,
                'category' => 'Control de Peso',
                'stock' => 50,
                'image_url' => 'https://ejemplo.com/batido-vainilla.jpg',
                'metadata' => [
                    'sabor' => 'Vainilla',
                    'presentacion' => '500g',
                    'beneficios' => ['Control de peso', 'Energía', 'Nutrición completa']
                ]
            ],
            [
                'name' => 'Té Concentrado',
                'description' => 'Té natural con extractos de hierbas para mejorar el metabolismo y la digestión.',
                'price' => 699.00,
                'category' => 'Control de Peso',
                'stock' => 30,
                'image_url' => 'https://ejemplo.com/te-concentrado.jpg',
                'metadata' => [
                    'sabor' => 'Natural',
                    'presentacion' => '500ml',
                    'beneficios' => ['Metabolismo', 'Digestión', 'Energía natural']
                ]
            ],
            [
                'name' => 'Aloe Vera Concentrado',
                'description' => 'Bebida de aloe vera puro para mejorar la digestión y la salud intestinal.',
                'price' => 499.00,
                'category' => 'Bienestar Digestivo',
                'stock' => 25,
                'image_url' => 'https://ejemplo.com/aloe-vera.jpg',
                'metadata' => [
                    'sabor' => 'Natural',
                    'presentacion' => '1L',
                    'beneficios' => ['Digestión', 'Salud intestinal', 'Hidratación']
                ]
            ],
            [
                'name' => 'Multivitamínico Premium',
                'description' => 'Complejo vitamínico con minerales esenciales para el bienestar general.',
                'price' => 799.00,
                'category' => 'Vitaminas',
                'stock' => 40,
                'image_url' => 'https://ejemplo.com/multivitaminico.jpg',
                'metadata' => [
                    'presentacion' => '60 tabletas',
                    'beneficios' => ['Energía', 'Sistema inmunológico', 'Salud general']
                ]
            ],
            [
                'name' => 'Proteína en Polvo',
                'description' => 'Proteína de alta calidad para el desarrollo muscular y la recuperación.',
                'price' => 1299.00,
                'category' => 'Proteínas',
                'stock' => 35,
                'image_url' => 'https://ejemplo.com/proteina.jpg',
                'metadata' => [
                    'sabor' => 'Chocolate',
                    'presentacion' => '750g',
                    'beneficios' => ['Músculo', 'Recuperación', 'Energía']
                ]
            ]
        ];

        foreach ($products as $product) {
            // Convertir el array metadata a JSON
            if (isset($product['metadata'])) {
                $product['metadata'] = json_encode($product['metadata']);
            }
            Product::create($product);
        }
    }
}
