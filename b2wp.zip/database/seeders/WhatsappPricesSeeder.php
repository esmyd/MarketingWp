<?php

namespace Database\Seeders;

use App\Models\WhatsappMenu;
use App\Models\WhatsappMenuItem;
use App\Models\WhatsappPrice;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;

class WhatsappPricesSeeder extends Seeder
{
    public function run(): void
    {
        try {
            // Get or create the main menu
            $mainMenu = WhatsappMenu::firstOrCreate(
                ['action_id' => 'products_menu'],
                [
                    'business_profile_id' => 1, // Assuming this is the default business profile
                    'title' => 'Catálogo de Productos',
                    'description' => 'Selecciona una categoría',
                    'type' => 'list',
                    'content' => 'Nuestras categorías de productos',
                    'button_text' => 'Ver categorías',
                    'icon' => '🛍️',
                    'order' => 1,
                    'is_active' => true
                ]
            );

            // Crear categorías principales del menú
            $menuCategories = [
                [
                    'action_id' => 'control_de_peso',
                    'title' => 'Control de Peso',
                    'description' => 'Productos para el control de peso',
                    'icon' => '⚖️',
                    'order' => 1
                ],
                [
                    'action_id' => 'bienestar_digestivo',
                    'title' => 'Bienestar Digestivo',
                    'description' => 'Productos para el bienestar digestivo',
                    'icon' => '🌿',
                    'order' => 2
                ],
                [
                    'action_id' => 'vitaminas',
                    'title' => 'Vitaminas',
                    'description' => 'Suplementos vitamínicos',
                    'icon' => '💊',
                    'order' => 3
                ],
                [
                    'action_id' => 'proteinas',
                    'title' => 'Proteínas',
                    'description' => 'Productos proteicos',
                    'icon' => '💪',
                    'order' => 4
                ],
                [
                    'action_id' => 'combos',
                    'title' => 'Combos',
                    'description' => 'Combos especiales',
                    'icon' => '🎁',
                    'order' => 5
                ],
                [
                    'action_id' => 'kits_especiales',
                    'title' => 'Kits Especiales',
                    'description' => 'Kits especiales',
                    'icon' => '📦',
                    'order' => 6
                ],
                [
                    'action_id' => 'combos_desayuno',
                    'title' => 'Combos Desayuno',
                    'description' => 'Combos para desayunos y meriendas',
                    'icon' => '🍳',
                    'order' => 7
                ]
            ];

            // Crear los items del menú
            foreach ($menuCategories as $category) {
                WhatsappMenuItem::firstOrCreate(
                    [
                        'menu_id' => $mainMenu->id,
                        'action_id' => $category['action_id']
                    ],
                    [
                        'title' => $category['title'],
                        'description' => $category['description'],
                        'icon' => $category['icon'],
                        'order' => $category['order'],
                        'is_active' => true
                    ]
                );
            }

            $products = [
                [
                    'sku' => '1001',
                    'name' => 'Batido F1 Vainilla',
                    'description' => 'Batido nutricional con proteína de soya y 23 vitaminas y minerales esenciales',
                    'price' => 899.00,
                    'category' => 'Control de Peso',
                    'is_promo' => false,
                    'metadata' => [
                        'quantity' => '550g',
                        'flavor' => 'Vainilla',
                        'format' => 'Polvo',
                        'benefits' => 'Control de peso, Energía, Nutrición balanceada',
                        'nutritional_info' => 'Proteína: 18g, Carbohidratos: 24g, Grasas: 3g, Calorías: 200'
                    ]
                ],
                [
                    'sku' => '1002',
                    'name' => 'Té Concentrado',
                    'description' => 'Bebida concentrada de té verde y hierbas naturales',
                    'price' => 699.00,
                    'category' => 'Control de Peso',
                    'is_promo' => true,
                    'promo_price' => 599.00,
                    'metadata' => [
                        'quantity' => '500ml',
                        'flavor' => 'Original',
                        'format' => 'Líquido',
                        'benefits' => 'Metabolismo, Energía, Antioxidantes',
                        'nutritional_info' => 'Calorías: 5 por porción'
                    ]
                ],
                [
                    'sku' => '2001',
                    'name' => 'Aloe Vera',
                    'description' => 'Bebida concentrada de aloe vera para la digestión',
                    'price' => 499.00,
                    'category' => 'Bienestar Digestivo',
                    'is_promo' => false,
                    'metadata' => [
                        'quantity' => '1L',
                        'flavor' => 'Mango',
                        'format' => 'Líquido',
                        'benefits' => 'Digestión, Hidratación, Bienestar general',
                        'nutritional_info' => 'Calorías: 10 por porción'
                    ]
                ],
                [
                    'sku' => '3001',
                    'name' => 'Multivitamínico',
                    'description' => 'Complejo multivitamínico completo con minerales',
                    'price' => 799.00,
                    'category' => 'Vitaminas',
                    'is_promo' => false,
                    'metadata' => [
                        'quantity' => '60 tabletas',
                        'flavor' => 'Natural',
                        'format' => 'Tabletas',
                        'benefits' => 'Nutrición celular, Energía, Sistema inmunológico',
                        'nutritional_info' => 'Vitaminas A-Z, Minerales esenciales'
                    ]
                ],
                [
                    'sku' => '4001',
                    'name' => 'Proteína en Polvo',
                    'description' => 'Proteína de suero de leche de alta calidad',
                    'price' => 1299.00,
                    'category' => 'Proteínas',
                    'is_promo' => true,
                    'promo_price' => 1099.00,
                    'metadata' => [
                        'quantity' => '750g',
                        'flavor' => 'Chocolate',
                        'format' => 'Polvo',
                        'benefits' => 'Masa muscular, Recuperación, Nutrición deportiva',
                        'nutritional_info' => 'Proteína: 20g, Carbohidratos: 3g, Grasas: 1g, Calorías: 110'
                    ]
                ],
                [
                    'sku' => '5001',
                    'name' => 'Combo Desayuno Premium',
                    'description' => 'Combo completo para un desayuno saludable y nutritivo',
                    'price' => 2499.00,
                    'category' => 'Combos',
                    'is_promo' => true,
                    'promo_price' => 1999.00,
                    'metadata' => [
                        'quantity' => '1 combo',
                        'contents' => 'Batido F1, Té Concentrado, Aloe Vera',
                        'format' => 'Combo',
                        'benefits' => 'Nutrición completa, Energía, Control de peso',
                        'nutritional_info' => 'Incluye todos los nutrientes necesarios para el día'
                    ]
                ],
                [
                    'sku' => '5002',
                    'name' => 'Combo Bienestar Total',
                    'description' => 'Combo completo para el bienestar general',
                    'price' => 3299.00,
                    'category' => 'Combos',
                    'is_promo' => false,
                    'metadata' => [
                        'quantity' => '1 combo',
                        'contents' => 'Multivitamínico, Aloe Vera, Proteína en Polvo',
                        'format' => 'Combo',
                        'benefits' => 'Nutrición completa, Digestión, Masa muscular',
                        'nutritional_info' => 'Combinación perfecta para el bienestar general'
                    ]
                ],
                [
                    'sku' => '5003',
                    'name' => 'Combo Desayuno Express',
                    'description' => 'Combo rápido y nutritivo para el desayuno',
                    'price' => 1799.00,
                    'category' => 'Combos',
                    'is_promo' => true,
                    'promo_price' => 1499.00,
                    'metadata' => [
                        'quantity' => '1 combo',
                        'contents' => 'Batido F1, Té Concentrado',
                        'format' => 'Combo',
                        'benefits' => 'Energía rápida, Control de peso',
                        'nutritional_info' => 'Nutrición esencial para empezar el día'
                    ]
                ],
                [
                    'sku' => '6001',
                    'name' => 'Kit Detox 7 Días',
                    'description' => 'Kit completo para programa detox de 7 días',
                    'price' => 3999.00,
                    'category' => 'Kits Especiales',
                    'is_promo' => true,
                    'promo_price' => 3499.00,
                    'metadata' => [
                        'quantity' => '1 kit',
                        'contents' => 'Té Concentrado, Aloe Vera, Batido F1',
                        'format' => 'Kit',
                        'benefits' => 'Desintoxicación, Control de peso, Energía',
                        'nutritional_info' => 'Programa completo de 7 días'
                    ]
                ],
                [
                    'sku' => '6002',
                    'name' => 'Kit Nutrición Familiar',
                    'description' => 'Kit completo para toda la familia',
                    'price' => 4999.00,
                    'category' => 'Kits Especiales',
                    'is_promo' => false,
                    'metadata' => [
                        'quantity' => '1 kit',
                        'contents' => 'Multivitamínico x2, Batido F1 x2, Aloe Vera',
                        'format' => 'Kit',
                        'benefits' => 'Nutrición familiar, Bienestar general',
                        'nutritional_info' => 'Nutrición completa para toda la familia'
                    ]
                ],
                [
                    'sku' => '7001',
                    'name' => 'Combo Desayuno Energético',
                    'description' => 'Combo perfecto para empezar el día con energía',
                    'price' => 1299.00,
                    'category' => 'Combos Desayuno',
                    'is_promo' => true,
                    'promo_price' => 1099.00,
                    'metadata' => [
                        'quantity' => '1 combo',
                        'contents' => 'Batido F1 Vainilla, Té Concentrado, Aloe Vera',
                        'format' => 'Combo',
                        'benefits' => 'Energía, Nutrición, Hidratación',
                        'nutritional_info' => 'Proteínas, Antioxidantes, Vitaminas'
                    ]
                ],
                [
                    'sku' => '7002',
                    'name' => 'Combo Desayuno Clásico',
                    'description' => 'Desayuno completo con waffles y huevos',
                    'price' => 1499.00,
                    'category' => 'Combos Desayuno',
                    'is_promo' => false,
                    'metadata' => [
                        'quantity' => '1 combo',
                        'contents' => 'Waffles de proteína, Huevos revueltos, Té Concentrado',
                        'format' => 'Combo',
                        'benefits' => 'Proteínas, Energía, Saciedad',
                        'nutritional_info' => 'Alto en proteínas, Bajo en carbohidratos'
                    ]
                ],
                [
                    'sku' => '7003',
                    'name' => 'Combo Merienda Saludable',
                    'description' => 'Merienda nutritiva para media mañana',
                    'price' => 999.00,
                    'category' => 'Combos Desayuno',
                    'is_promo' => true,
                    'promo_price' => 899.00,
                    'metadata' => [
                        'quantity' => '1 combo',
                        'contents' => 'Batido F1 Chocolate, Aloe Vera',
                        'format' => 'Combo',
                        'benefits' => 'Energía, Nutrición, Hidratación',
                        'nutritional_info' => 'Proteínas y vitaminas esenciales'
                    ]
                ],
                [
                    'sku' => '7004',
                    'name' => 'Combo Desayuno Premium',
                    'description' => 'Desayuno gourmet con opciones premium',
                    'price' => 1799.00,
                    'category' => 'Combos Desayuno',
                    'is_promo' => false,
                    'metadata' => [
                        'quantity' => '1 combo',
                        'contents' => 'Waffles de proteína, Huevos benedictinos, Té Concentrado, Aloe Vera',
                        'format' => 'Combo',
                        'benefits' => 'Nutrición premium, Energía duradera',
                        'nutritional_info' => 'Balance perfecto de macronutrientes'
                    ]
                ],
                [
                    'sku' => '7005',
                    'name' => 'Combo Merienda Express',
                    'description' => 'Merienda rápida y nutritiva',
                    'price' => 799.00,
                    'category' => 'Combos Desayuno',
                    'is_promo' => true,
                    'promo_price' => 699.00,
                    'metadata' => [
                        'quantity' => '1 combo',
                        'contents' => 'Batido F1 Frutas, Té Concentrado',
                        'format' => 'Combo',
                        'benefits' => 'Energía rápida, Nutrición esencial',
                        'nutritional_info' => 'Vitaminas y minerales esenciales'
                    ]
                ]
            ];

            foreach ($products as $product) {
                try {
                    // Get or create menu item for the category
                    $menuItem = WhatsappMenuItem::firstOrCreate(
                        [
                            'menu_id' => $mainMenu->id,
                            'action_id' => strtolower(str_replace(' ', '_', $product['category']))
                        ],
                        [
                            'title' => $product['category'],
                            'description' => 'Productos de ' . $product['category'],
                            'icon' => '📦',
                            'order' => 1,
                            'is_active' => true
                        ]
                    );

                    // Ensure the name is not longer than 24 characters
                    $name = Str::limit($product['name'], 24, '');

                    // Create or update the price
                    WhatsappPrice::updateOrCreate(
                        ['sku' => $product['sku']],
                        [
                            'menu_item_id' => $menuItem->id,
                            'category' => $product['category'],
                            'name' => $name,
                            'description' => $product['description'],
                            'price' => $product['price'],
                            'promo_price' => $product['promo_price'] ?? null,
                            'is_promo' => $product['is_promo'] ?? false,
                            'promo_start_date' => $product['is_promo'] ? now() : null,
                            'promo_end_date' => $product['is_promo'] ? now()->addDays(30) : null,
                            'currency' => 'USD',
                            'is_active' => true,
                            'metadata' => json_encode($product['metadata'])
                        ]
                    );
                } catch (\Exception $e) {
                    Log::error("Error creating product {$product['sku']}: " . $e->getMessage());
                    continue;
                }
            }
        } catch (\Exception $e) {
            Log::error("Error in WhatsappPricesSeeder: " . $e->getMessage());
            throw $e;
        }
    }
}
