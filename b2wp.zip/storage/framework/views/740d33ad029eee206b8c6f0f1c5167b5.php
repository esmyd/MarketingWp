<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Gestión de Menús y Categorías</h3>
                    <div class="card-tools">
                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#createMenuModal">
                            <i class="fas fa-plus"></i> Nuevo Menú
                        </button>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Título</th>
                                    <th>Tipo</th>
                                    <th>Estado</th>
                                    <th>Orden</th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($menu->id); ?></td>
                                    <td>
                                        <i class="<?php echo e($menu->icon); ?>"></i>
                                        <?php echo e($menu->title); ?>

                                    </td>
                                    <td><?php echo e($menu->type); ?></td>
                                    <td>
                                        <span class="badge badge-<?php echo e($menu->is_active ? 'success' : 'danger'); ?>">
                                            <?php echo e($menu->is_active ? 'Activo' : 'Inactivo'); ?>

                                        </span>
                                    </td>
                                    <td><?php echo e($menu->order); ?></td>
                                    <td>
                                        <div class="btn-group">
                                            <button type="button" class="btn btn-sm btn-info" data-toggle="modal" data-target="#editMenuModal<?php echo e($menu->id); ?>">
                                                <i class="fas fa-edit"></i>
                                            </button>
                                            <button type="button" class="btn btn-sm btn-success" data-toggle="modal" data-target="#manageItemsModal<?php echo e($menu->id); ?>">
                                                <i class="fas fa-list"></i>
                                            </button>
                                            <button type="button" class="btn btn-sm btn-danger" onclick="deleteMenu(<?php echo e($menu->id); ?>)">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal para crear menú -->
<div class="modal fade" id="createMenuModal" tabindex="-1" role="dialog" aria-labelledby="createMenuModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="createMenuModalLabel">Crear Nuevo Menú</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="<?php echo e(route('admin.menus.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="form-group">
                        <label for="title">Título</label>
                        <input type="text" class="form-control" id="title" name="title" required>
                    </div>
                    <div class="form-group">
                        <label for="description">Descripción</label>
                        <textarea class="form-control" id="description" name="description" rows="3"></textarea>
                    </div>
                    <div class="form-group">
                        <label for="type">Tipo</label>
                        <select class="form-control" id="type" name="type" required>
                            <option value="button">Botón</option>
                            <option value="list">Lista</option>
                            <option value="text">Texto</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="content">Contenido</label>
                        <textarea class="form-control" id="content" name="content" rows="3" required></textarea>
                    </div>
                    <div class="form-group">
                        <label for="button_text">Texto del Botón</label>
                        <input type="text" class="form-control" id="button_text" name="button_text">
                    </div>
                    <div class="form-group">
                        <label for="icon">Icono</label>
                        <input type="text" class="form-control" id="icon" name="icon" placeholder="Ej: 🛍️">
                    </div>
                    <div class="form-group">
                        <label for="action_id">ID de Acción</label>
                        <input type="text" class="form-control" id="action_id" name="action_id" required>
                    </div>
                    <div class="form-group">
                        <label for="order">Orden</label>
                        <input type="number" class="form-control" id="order" name="order" value="0">
                    </div>
                    <div class="form-group">
                        <div class="custom-control custom-switch">
                            <input type="checkbox" class="custom-control-input" id="is_active" name="is_active" checked>
                            <label class="custom-control-label" for="is_active">Activo</label>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Guardar</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<!-- Modal para editar menú -->
<div class="modal fade" id="editMenuModal<?php echo e($menu->id); ?>" tabindex="-1" role="dialog" aria-labelledby="editMenuModalLabel<?php echo e($menu->id); ?>" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editMenuModalLabel<?php echo e($menu->id); ?>">Editar Menú</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="<?php echo e(route('admin.menus.update', $menu->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="modal-body">
                    <div class="form-group">
                        <label for="title<?php echo e($menu->id); ?>">Título</label>
                        <input type="text" class="form-control" id="title<?php echo e($menu->id); ?>" name="title" value="<?php echo e($menu->title); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="description<?php echo e($menu->id); ?>">Descripción</label>
                        <textarea class="form-control" id="description<?php echo e($menu->id); ?>" name="description" rows="3"><?php echo e($menu->description); ?></textarea>
                    </div>
                    <div class="form-group">
                        <label for="type<?php echo e($menu->id); ?>">Tipo</label>
                        <select class="form-control" id="type<?php echo e($menu->id); ?>" name="type" required>
                            <option value="button" <?php echo e($menu->type === 'button' ? 'selected' : ''); ?>>Botón</option>
                            <option value="list" <?php echo e($menu->type === 'list' ? 'selected' : ''); ?>>Lista</option>
                            <option value="text" <?php echo e($menu->type === 'text' ? 'selected' : ''); ?>>Texto</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="content<?php echo e($menu->id); ?>">Contenido</label>
                        <textarea class="form-control" id="content<?php echo e($menu->id); ?>" name="content" rows="3" required><?php echo e($menu->content); ?></textarea>
                    </div>
                    <div class="form-group">
                        <label for="button_text<?php echo e($menu->id); ?>">Texto del Botón</label>
                        <input type="text" class="form-control" id="button_text<?php echo e($menu->id); ?>" name="button_text" value="<?php echo e($menu->button_text); ?>">
                    </div>
                    <div class="form-group">
                        <label for="icon<?php echo e($menu->id); ?>">Icono</label>
                        <input type="text" class="form-control" id="icon<?php echo e($menu->id); ?>" name="icon" value="<?php echo e($menu->icon); ?>" placeholder="Ej: 🛍️">
                    </div>
                    <div class="form-group">
                        <label for="action_id<?php echo e($menu->id); ?>">ID de Acción</label>
                        <input type="text" class="form-control" id="action_id<?php echo e($menu->id); ?>" name="action_id" value="<?php echo e($menu->action_id); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="order<?php echo e($menu->id); ?>">Orden</label>
                        <input type="number" class="form-control" id="order<?php echo e($menu->id); ?>" name="order" value="<?php echo e($menu->order); ?>">
                    </div>
                    <div class="form-group">
                        <div class="custom-control custom-switch">
                            <input type="checkbox" class="custom-control-input" id="is_active<?php echo e($menu->id); ?>" name="is_active" <?php echo e($menu->is_active ? 'checked' : ''); ?>>
                            <label class="custom-control-label" for="is_active<?php echo e($menu->id); ?>">Activo</label>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Guardar Cambios</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal para gestionar items -->
<div class="modal fade" id="manageItemsModal<?php echo e($menu->id); ?>" tabindex="-1" role="dialog" aria-labelledby="manageItemsModalLabel<?php echo e($menu->id); ?>" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="manageItemsModalLabel<?php echo e($menu->id); ?>">Gestionar Items - <?php echo e($menu->title); ?></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <button type="button" class="btn btn-primary" onclick="showCreateItemModal(<?php echo e($menu->id); ?>)">
                        <i class="fas fa-plus"></i> Nuevo Item
                    </button>
                </div>
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Título</th>
                                <th>Descripción</th>
                                <th>ID de Acción</th>
                                <th>Estado</th>
                                <th>Orden</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $menu->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <i class="<?php echo e($item->icon); ?>"></i>
                                    <?php echo e($item->title); ?>

                                </td>
                                <td><?php echo e($item->description); ?></td>
                                <td><?php echo e($item->action_id); ?></td>
                                <td>
                                    <span class="badge badge-<?php echo e($item->is_active ? 'success' : 'danger'); ?>">
                                        <?php echo e($item->is_active ? 'Activo' : 'Inactivo'); ?>

                                    </span>
                                </td>
                                <td><?php echo e($item->order); ?></td>
                                <td>
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-sm btn-info" onclick="editItem(<?php echo e($item->id); ?>)">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button type="button" class="btn btn-sm btn-danger" onclick="deleteItem(<?php echo e($item->id); ?>)">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
function deleteMenu(id) {
    if (confirm('¿Estás seguro de que deseas eliminar este menú?')) {
        axios.delete(`/admin/menus/${id}`)
            .then(response => {
                window.location.reload();
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Ha ocurrido un error al eliminar el menú');
            });
    }
}

function deleteItem(id) {
    if (confirm('¿Estás seguro de que deseas eliminar este item?')) {
        axios.delete(`/admin/menu-items/${id}`)
            .then(response => {
                window.location.reload();
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Ha ocurrido un error al eliminar el item');
            });
    }
}

function showCreateItemModal(menuId) {
    // Implementar lógica para mostrar modal de creación de item
}

function editItem(itemId) {
    // Implementar lógica para editar item
}
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programas\Laragon\laragon\www\WhatsApp\MarketingWp\resources\views/admin/menus/index.blade.php ENDPATH**/ ?>