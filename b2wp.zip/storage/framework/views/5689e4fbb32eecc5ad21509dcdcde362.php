<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Configuración del Chatbot</h3>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('admin.chatbot.config.update')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <!-- Configuración General -->
                        <div class="card card-primary">
                            <div class="card-header">
                                <h3 class="card-title">Configuración General</h3>
                            </div>
                            <div class="card-body">
                                <div class="form-group">
                                    <label for="business_name">Nombre del Negocio</label>
                                    <input type="text" class="form-control" id="business_name" name="business_name" value="<?php echo e($config->business_name); ?>" required>
                                </div>
                                <div class="form-group">
                                    <label for="business_description">Descripción del Negocio</label>
                                    <textarea class="form-control" id="business_description" name="business_description" rows="3"><?php echo e($config->business_description); ?></textarea>
                                </div>
                                <div class="form-group">
                                    <label for="business_hours">Horario de Atención</label>
                                    <input type="text" class="form-control" id="business_hours" name="business_hours" value="<?php echo e($config->business_hours); ?>">
                                </div>
                            </div>
                        </div>

                        <!-- Mensajes de Bienvenida -->
                        <div class="card card-primary">
                            <div class="card-header">
                                <h3 class="card-title">Mensajes de Bienvenida</h3>
                            </div>
                            <div class="card-body">
                                <div class="form-group">
                                    <label for="welcome_message">Mensaje de Bienvenida</label>
                                    <textarea class="form-control" id="welcome_message" name="welcome_message" rows="3" required><?php echo e($config->welcome_message); ?></textarea>
                                    <small class="form-text text-muted">Este mensaje se muestra cuando un usuario inicia una conversación.</small>
                                </div>
                                <div class="form-group">
                                    <label for="menu_message">Mensaje del Menú Principal</label>
                                    <textarea class="form-control" id="menu_message" name="menu_message" rows="3" required><?php echo e($config->menu_message); ?></textarea>
                                    <small class="form-text text-muted">Este mensaje se muestra cuando el usuario solicita ver el menú.</small>
                                </div>
                            </div>
                        </div>

                        <!-- Comandos del Menú -->
                        <div class="card card-primary">
                            <div class="card-header">
                                <h3 class="card-title">Comandos del Menú</h3>
                            </div>
                            <div class="card-body">
                                <div class="form-group">
                                    <label for="menu_command">Comando para Ver Menú</label>
                                    <input type="text" class="form-control" id="menu_command" name="menu_command" value="<?php echo e($config->menu_command); ?>" required>
                                    <small class="form-text text-muted">Comando que el usuario debe escribir para ver el menú (ej: "menu", "carta").</small>
                                </div>
                                <div class="form-group">
                                    <label for="help_command">Comando de Ayuda</label>
                                    <input type="text" class="form-control" id="help_command" name="help_command" value="<?php echo e($config->help_command); ?>" required>
                                    <small class="form-text text-muted">Comando que el usuario debe escribir para obtener ayuda (ej: "ayuda", "help").</small>
                                </div>
                            </div>
                        </div>

                        <!-- Respuestas Automáticas -->
                        <div class="card card-primary">
                            <div class="card-header">
                                <h3 class="card-title">Respuestas Automáticas</h3>
                            </div>
                            <div class="card-body">
                                <div class="form-group">
                                    <label for="offline_message">Mensaje Fuera de Horario</label>
                                    <textarea class="form-control" id="offline_message" name="offline_message" rows="3"><?php echo e($config->offline_message); ?></textarea>
                                    <small class="form-text text-muted">Mensaje que se muestra cuando el usuario escribe fuera del horario de atención.</small>
                                </div>
                                <div class="form-group">
                                    <label for="error_message">Mensaje de Error</label>
                                    <textarea class="form-control" id="error_message" name="error_message" rows="3"><?php echo e($config->error_message); ?></textarea>
                                    <small class="form-text text-muted">Mensaje que se muestra cuando ocurre un error en el sistema.</small>
                                </div>
                                <div class="form-group">
                                    <label for="not_found_message">Mensaje de No Encontrado</label>
                                    <textarea class="form-control" id="not_found_message" name="not_found_message" rows="3"><?php echo e($config->not_found_message); ?></textarea>
                                    <small class="form-text text-muted">Mensaje que se muestra cuando no se encuentra un producto o categoría.</small>
                                </div>
                            </div>
                        </div>

                        <!-- Configuración de Pedidos -->
                        <div class="card card-primary">
                            <div class="card-header">
                                <h3 class="card-title">Configuración de Pedidos</h3>
                            </div>
                            <div class="card-body">
                                <div class="form-group">
                                    <label for="order_confirmation_message">Mensaje de Confirmación de Pedido</label>
                                    <textarea class="form-control" id="order_confirmation_message" name="order_confirmation_message" rows="3"><?php echo e($config->order_confirmation_message); ?></textarea>
                                    <small class="form-text text-muted">Mensaje que se muestra cuando se confirma un pedido.</small>
                                </div>
                                <div class="form-group">
                                    <label for="order_status_message">Mensaje de Estado del Pedido</label>
                                    <textarea class="form-control" id="order_status_message" name="order_status_message" rows="3"><?php echo e($config->order_status_message); ?></textarea>
                                    <small class="form-text text-muted">Mensaje que se muestra cuando se actualiza el estado de un pedido.</small>
                                </div>
                                <div class="form-group">
                                    <label for="payment_confirmation_message">Mensaje de Confirmación de Pago</label>
                                    <textarea class="form-control" id="payment_confirmation_message" name="payment_confirmation_message" rows="3"><?php echo e($config->payment_confirmation_message); ?></textarea>
                                    <small class="form-text text-muted">Mensaje que se muestra cuando se confirma un pago.</small>
                                </div>
                            </div>
                        </div>

                        <div class="card-footer">
                            <button type="submit" class="btn btn-primary">Guardar Configuración</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
$(document).ready(function() {
    // Inicializar textareas con editor enriquecido si es necesario
    // Ejemplo: tinymce.init({ selector: 'textarea' });
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programas\Laragon\laragon\www\WhatsApp\MarketingWp\resources\views/admin/chatbot/config.blade.php ENDPATH**/ ?>