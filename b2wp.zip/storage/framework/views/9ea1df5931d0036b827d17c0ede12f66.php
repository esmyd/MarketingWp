<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel Administrativo - WhatsApp Marketing</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body class="bg-gray-100">
    <div class="min-h-screen flex">
        <!-- Sidebar -->
        <div class="bg-gray-800 text-white w-64 space-y-6 py-7 px-2 absolute inset-y-0 left-0 transform -translate-x-full md:relative md:translate-x-0 transition duration-200 ease-in-out">
            <div class="flex items-center space-x-2 px-4">
                <i class="fab fa-whatsapp text-2xl"></i>
                <span class="text-2xl font-extrabold">Admin Panel</span>
            </div>
            <nav>
                <a href="<?php echo e(route('admin.dashboard')); ?>" class="block py-2.5 px-4 rounded transition duration-200 hover:bg-gray-700">
                    <i class="fas fa-home mr-2"></i>Dashboard
                </a>
                <a href="<?php echo e(route('admin.orders')); ?>" class="block py-2.5 px-4 rounded transition duration-200 hover:bg-gray-700">
                    <i class="fas fa-shopping-cart mr-2"></i>Pedidos
                </a>
                <a href="<?php echo e(route('admin.chats')); ?>" class="block py-2.5 px-4 rounded transition duration-200 hover:bg-gray-700">
                    <i class="fas fa-comments mr-2"></i>Chats
                </a>
                <!-- Chatbot Management -->
                <div class="px-4 py-2 text-gray-400 text-sm font-semibold">
                    Gestión del Chatbot
                </div>
                <a href="<?php echo e(route('admin.menus.index')); ?>" class="block py-2.5 px-4 rounded transition duration-200 hover:bg-gray-700">
                    <i class="fas fa-list mr-2"></i>Menús y Categorías
                </a>
                <a href="<?php echo e(route('admin.products.index')); ?>" class="block py-2.5 px-4 rounded transition duration-200 hover:bg-gray-700">
                    <i class="fas fa-box mr-2"></i>Productos
                </a>
                <a href="<?php echo e(route('admin.chatbot.config')); ?>" class="block py-2.5 px-4 rounded transition duration-200 hover:bg-gray-700">
                    <i class="fas fa-cog mr-2"></i>Configuración
                </a>
            </nav>
        </div>

        <!-- Main Content -->
        <div class="flex-1">
            <header class="bg-white shadow">
                <div class="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
                    <h1 class="text-3xl font-bold text-gray-900">
                        <?php echo $__env->yieldContent('header'); ?>
                    </h1>
                </div>
            </header>

            <main class="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
                <?php echo $__env->yieldContent('content'); ?>
            </main>
        </div>
    </div>
</body>
</html>
<?php /**PATH D:\Programas\Laragon\laragon\www\WhatsApp\MarketingWp\resources\views/admin/layouts/app.blade.php ENDPATH**/ ?>