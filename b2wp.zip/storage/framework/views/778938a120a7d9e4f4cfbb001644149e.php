<?php $__env->startSection('header', 'Productos'); ?>

<?php $__env->startSection('content'); ?>
<div class="bg-white shadow-sm rounded-lg overflow-hidden">
    <div class="p-6">
        <!-- Pestañas de navegación -->
        <div class="border-b border-gray-200">
            <nav class="-mb-px flex space-x-8">
                <a href="#products" class="border-blue-500 text-blue-600 whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm">
                    <i class="fas fa-box mr-2"></i>Productos
                </a>
                <a href="#categories" class="border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm">
                    <i class="fas fa-tags mr-2"></i>Categorías
                </a>
                <a href="#config" class="border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm">
                    <i class="fas fa-cog mr-2"></i>Configuración
                </a>
            </nav>
        </div>

        <!-- Contenido de las pestañas -->
        <div class="mt-6">
            <!-- Pestaña de Productos -->
            <div id="products" class="tab-content">
                <div class="flex justify-between items-center mb-4">
                    <div class="relative">
                        <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <i class="fas fa-search text-gray-400"></i>
                        </div>
                        <input type="text" class="pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500" placeholder="Buscar productos...">
                    </div>
                    <button type="button" class="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500" onclick="showCreateProductModal()">
                        <i class="fas fa-plus mr-2"></i>Nuevo Producto
                    </button>
                </div>

                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">SKU</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Nombre</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Categoría</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Precio</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Precio Promo</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Estado</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Acciones</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900"><?php echo e($product->sku); ?></td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="flex items-center">
                                        <i class="<?php echo e($product->icon); ?> mr-2"></i>
                                        <span class="text-sm text-gray-900"><?php echo e($product->name); ?></span>
                                    </div>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                    <?php if(is_object($product->category)): ?>
                                        <?php echo e($product->category->title); ?>

                                    <?php else: ?>
                                        <?php echo e($product->category); ?>

                                    <?php endif; ?>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">$<?php echo e(number_format($product->price, 2)); ?></td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                    <?php if($product->promo_price): ?>
                                        $<?php echo e(number_format($product->promo_price, 2)); ?>

                                    <?php else: ?>
                                        -
                                    <?php endif; ?>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full <?php echo e($product->is_active ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'); ?>">
                                        <?php echo e($product->is_active ? 'Activo' : 'Inactivo'); ?>

                                    </span>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                    <div class="flex space-x-2">
                                        <a href="<?php echo e(route('admin.products.edit', $product->id)); ?>" class="text-blue-600 hover:text-blue-900">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <a href="<?php echo e(route('admin.products.show', $product->id)); ?>" class="text-green-600 hover:text-green-900">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <form action="<?php echo e(route('admin.products.delete', $product->id)); ?>" method="POST" class="inline">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="text-red-600 hover:text-red-900" onclick="return confirm('¿Estás seguro de que deseas eliminar este producto?')">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Pestaña de Categorías -->
            <div id="categories" class="tab-content hidden">
                <div class="flex justify-between items-center mb-4">
                    <div class="relative">
                        <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <i class="fas fa-search text-gray-400"></i>
                        </div>
                        <input type="text" class="pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500" placeholder="Buscar categorías...">
                    </div>
                    <button type="button" class="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500" onclick="showCreateCategoryModal()">
                        <i class="fas fa-plus mr-2"></i>Nueva Categoría
                    </button>
                </div>

                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Nombre</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Descripción</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Estado</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Acciones</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900"><?php echo e($category->title); ?></td>
                                <td class="px-6 py-4 text-sm text-gray-500"><?php echo e($category->description); ?></td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full <?php echo e($category->is_active ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'); ?>">
                                        <?php echo e($category->is_active ? 'Activo' : 'Inactivo'); ?>

                                    </span>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                    <div class="flex space-x-2">
                                        <button onclick="editCategory(<?php echo e($category->id); ?>)" class="text-blue-600 hover:text-blue-900">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button onclick="deleteCategory(<?php echo e($category->id); ?>)" class="text-red-600 hover:text-red-900">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Pestaña de Configuración -->
            <div id="config" class="tab-content hidden">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <!-- Configuración General -->
                    <div class="bg-white overflow-hidden shadow-sm rounded-lg">
                        <div class="p-6">
                            <h3 class="text-lg font-medium text-gray-900 mb-4">Configuración General</h3>
                            <form action="<?php echo e(route('admin.chatbot.config.update')); ?>" method="POST" class="space-y-4">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <div>
                                    <label class="block text-sm font-medium text-gray-700">Nombre del Negocio</label>
                                    <input type="text" name="business_name" value="<?php echo e($config->business_name ?? ''); ?>" class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm">
                                </div>
                                <div>
                                    <label class="block text-sm font-medium text-gray-700">Descripción</label>
                                    <textarea name="business_description" rows="3" class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"><?php echo e($config->business_description ?? ''); ?></textarea>
                                </div>
                                <div>
                                    <label class="block text-sm font-medium text-gray-700">Horario de Atención</label>
                                    <input type="text" name="business_hours" value="<?php echo e($config->business_hours ?? ''); ?>" class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm">
                                </div>
                                <div class="flex justify-end">
                                    <button type="submit" class="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                                        <i class="fas fa-save mr-2"></i>Guardar Cambios
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>

                    <!-- Mensajes del Chatbot -->
                    <div class="bg-white overflow-hidden shadow-sm rounded-lg">
                        <div class="p-6">
                            <h3 class="text-lg font-medium text-gray-900 mb-4">Mensajes del Chatbot</h3>
                            <form action="<?php echo e(route('admin.chatbot.config.update')); ?>" method="POST" class="space-y-4">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <div>
                                    <label class="block text-sm font-medium text-gray-700">Mensaje de Bienvenida</label>
                                    <textarea name="welcome_message" rows="3" class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm" required><?php echo e($config->welcome_message ?? ''); ?></textarea>
                                </div>
                                <div>
                                    <label class="block text-sm font-medium text-gray-700">Mensaje del Menú</label>
                                    <textarea name="menu_message" rows="3" class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm" required><?php echo e($config->menu_message ?? ''); ?></textarea>
                                </div>
                                <div>
                                    <label class="block text-sm font-medium text-gray-700">Mensaje de Ayuda</label>
                                    <textarea name="help_message" rows="3" class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"><?php echo e($config->help_message ?? ''); ?></textarea>
                                </div>
                                <div class="flex justify-end">
                                    <button type="submit" class="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                                        <i class="fas fa-save mr-2"></i>Guardar Cambios
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modales -->
<?php echo $__env->make('admin.products.partials.create-product-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.products.partials.edit-product-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.products.partials.view-product-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.products.partials.create-category-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.products.partials.edit-category-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<!-- Axios CDN -->
<script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>

<script>
// Función para manejar las pestañas
document.querySelectorAll('nav a').forEach(link => {
    link.addEventListener('click', (e) => {
        e.preventDefault();
        const targetId = link.getAttribute('href').substring(1);

        // Actualizar pestañas
        document.querySelectorAll('nav a').forEach(l => {
            l.classList.remove('border-blue-500', 'text-blue-600');
            l.classList.add('border-transparent', 'text-gray-500');
        });
        link.classList.remove('border-transparent', 'text-gray-500');
        link.classList.add('border-blue-500', 'text-blue-600');

        // Mostrar contenido
        document.querySelectorAll('.tab-content').forEach(content => {
            content.classList.add('hidden');
        });
        document.getElementById(targetId).classList.remove('hidden');
    });
});

// Funciones para los modales
function showCreateProductModal() {
    // Implementar lógica para mostrar el modal de creación
}

function editProduct(id) {
    axios.get(`/admin/products/${id}`)
        .then(response => {
            const product = response.data;
            // Llenar el formulario de edición con los datos del producto
            document.getElementById('edit-product-sku').value = product.sku;
            document.getElementById('edit-product-name').value = product.name;
            document.getElementById('edit-product-category').value = product.menu_item_id;
            document.getElementById('edit-product-price').value = product.price;
            document.getElementById('edit-product-promo-price').value = product.promo_price || '';
            document.getElementById('edit-product-description').value = product.description || '';
            document.getElementById('edit-product-benefits').value = product.benefits || '';
            document.getElementById('edit-product-nutritional-info').value = product.nutritional_info || '';
            document.getElementById('edit-product-icon').value = product.icon || '';
            document.getElementById('edit-product-is-active').checked = product.is_active;
            // Mostrar el modal de edición
            document.getElementById('edit-product-modal').classList.remove('hidden');
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Ha ocurrido un error al cargar el producto');
        });
}

function viewProduct(id) {
    // Implementar lógica para ver detalles
}

function deleteProduct(id) {
    if (confirm('¿Estás seguro de que deseas eliminar este producto?')) {
        axios.delete(`/admin/products/${id}`)
            .then(response => {
                window.location.reload();
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Ha ocurrido un error al eliminar el producto');
            });
    }
}

function showCreateCategoryModal() {
    // Implementar lógica para mostrar el modal de creación de categoría
}

function editCategory(id) {
    axios.get(`/admin/categories/${id}`)
        .then(response => {
            const category = response.data;
            // Llenar el formulario de edición con los datos de la categoría
            document.getElementById('edit-category-title').value = category.title;
            document.getElementById('edit-category-description').value = category.description || '';
            document.getElementById('edit-category-is-active').checked = category.is_active;
            // Mostrar el modal de edición
            document.getElementById('edit-category-modal').classList.remove('hidden');
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Ha ocurrido un error al cargar la categoría');
        });
}

function deleteCategory(id) {
    if (confirm('¿Estás seguro de que deseas eliminar esta categoría?')) {
        axios.delete(`/admin/categories/${id}`)
            .then(response => {
                window.location.reload();
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Ha ocurrido un error al eliminar la categoría');
            });
    }
}
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programas\Laragon\laragon\www\WhatsApp\MarketingWp\resources\views/admin/products/index.blade.php ENDPATH**/ ?>