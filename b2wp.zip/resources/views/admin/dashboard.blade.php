@extends('admin.layouts.app')

@section('header', 'Dashboard')

@section('content')
<div class="grid grid-cols-1 md:grid-cols-2 gap-6">
    <!-- Orders Summary -->
    <div class="bg-white overflow-hidden shadow-sm rounded-lg">
        <div class="p-6">
            <h2 class="text-xl font-semibold mb-4">Últimos Pedidos</h2>
            <div class="space-y-4">
                @forelse($orders->take(5) as $order)
                    <div class="border-b pb-4">
                        <div class="flex justify-between items-center">
                            <div>
                                <p class="font-medium">{{ $order->contact->name ?? 'Cliente' }}</p>
                                <p class="text-sm text-gray-600">{{ $order->created_at->format('d/m/Y H:i') }}</p>
                            </div>
                            <span class="px-3 py-1 rounded-full text-sm {{ $order->status === 'completed' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800' }}">
                                {{ $order->status }}
                            </span>
                        </div>
                    </div>
                @empty
                    <p class="text-gray-500">No hay pedidos recientes</p>
                @endforelse
            </div>
            <a href="{{ route('admin.orders') }}" class="mt-4 inline-block text-blue-600 hover:text-blue-800">Ver todos los pedidos →</a>
        </div>
    </div>

    <!-- Messages Summary -->
    <div class="bg-white overflow-hidden shadow-sm rounded-lg">
        <div class="p-6">
            <h2 class="text-xl font-semibold mb-4">Últimos Mensajes</h2>
            <div class="space-y-4">
                @forelse($messages->take(5) as $message)
                    <div class="border-b pb-4">
                        <div class="flex justify-between items-center">
                            <div>
                                <p class="font-medium">{{ $message->contact->name ?? 'Cliente' }}</p>
                                @php
                                    $content = $message->content;
                                    $decoded = null;
                                    try {
                                        $decoded = json_decode($content, true, 512, JSON_THROW_ON_ERROR);
                                    } catch (\Throwable $e) {
                                        $decoded = null;
                                    }
                                @endphp
                                @if(is_array($decoded) && isset($decoded['title']))
                                    <p class="text-sm text-gray-800 font-semibold">{{ $decoded['title'] }}</p>
                                    @if(isset($decoded['description']))
                                        <p class="text-xs text-gray-600">{{ \Illuminate\Support\Str::limit($decoded['description'], 80) }}</p>
                                    @endif
                                @else
                                    <p class="text-sm text-gray-600 truncate max-w-md">{{ \Illuminate\Support\Str::limit($content, 80) }}</p>
                                @endif
                                <p class="text-xs text-gray-500">{{ $message->created_at->format('d/m/Y H:i') }}</p>
                            </div>
                        </div>
                    </div>
                @empty
                    <p class="text-gray-500">No hay mensajes recientes</p>
                @endforelse
            </div>
            <a href="{{ route('admin.messages') }}" class="mt-4 inline-block text-blue-600 hover:text-blue-800">Ver todos los mensajes →</a>
        </div>
    </div>
</div>
@endsection
