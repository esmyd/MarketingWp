@extends('admin.layouts.app')

@section('header')
    <div class="flex items-center space-x-3">
        <div class="w-10 h-10 rounded-full bg-green-200 flex items-center justify-center text-lg font-bold text-green-700">
            {{ strtoupper(mb_substr($contact->name ?? 'C', 0, 1)) }}
        </div>
        <div>
            <div class="font-semibold">{{ $contact->name ?? 'Cliente' }}</div>
            <div class="text-xs text-gray-400">{{ $contact->phone_number }}</div>
        </div>
    </div>
@endsection

@section('content')
<style>
    .wa-bubble-in {
        background: #f1f0f0;
        color: #222;
        border-radius: 0 1.1em 1.1em 1.1em;
        box-shadow: 0 1px 1px rgba(0,0,0,0.04);
    }
    .wa-bubble-out {
        background: #d1f7c4;
        color: #222;
        border-radius: 1.1em 0 1.1em 1.1em;
        box-shadow: 0 1px 1px rgba(0,0,0,0.04);
    }
</style>
<div class="flex flex-col h-[70vh] bg-white shadow-sm rounded-lg overflow-hidden border border-gray-200">
    <div class="flex-1 overflow-y-auto p-6 space-y-2" id="chat-messages">
        @forelse($messages as $msg)
            @php
                $isIncoming = $msg->type === 'incoming';
                $bubbleClass = $isIncoming ? 'wa-bubble-in self-start' : 'wa-bubble-out self-end';
                $align = $isIncoming ? 'justify-start' : 'justify-end';
                $content = $msg->content;
                $decoded = null;
                try {
                    $decoded = json_decode($content, true, 512, JSON_THROW_ON_ERROR);
                } catch (\Throwable $e) {
                    $decoded = null;
                }
            @endphp
            <div class="flex {{ $align }}">
                <div class="max-w-xs px-4 py-2 mb-1 {{ $bubbleClass }}">
                    @if(is_array($decoded) && isset($decoded['title']))
                        <div class="font-semibold">{{ $decoded['title'] }}</div>
                        @if(isset($decoded['description']))
                            <div class="text-xs text-gray-600">{{ \Illuminate\Support\Str::limit($decoded['description'], 120) }}</div>
                        @endif
                    @else
                        {{ $content }}
                    @endif
                    <div class="text-[10px] text-gray-400 text-right mt-1">{{ $msg->created_at->format('d/m/Y H:i') }}</div>
                </div>
            </div>
        @empty
            <div class="text-center text-gray-400">No hay mensajes en este chat</div>
        @endforelse
    </div>
</div>
@endsection
