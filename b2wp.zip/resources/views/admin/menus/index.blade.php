@extends('admin.layouts.app')

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Gestión de Menús y Categorías</h3>
                    <div class="card-tools">
                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#createMenuModal">
                            <i class="fas fa-plus"></i> Nuevo Menú
                        </button>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Título</th>
                                    <th>Tipo</th>
                                    <th>Estado</th>
                                    <th>Orden</th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($menus as $menu)
                                <tr>
                                    <td>{{ $menu->id }}</td>
                                    <td>
                                        <i class="{{ $menu->icon }}"></i>
                                        {{ $menu->title }}
                                    </td>
                                    <td>{{ $menu->type }}</td>
                                    <td>
                                        <span class="badge badge-{{ $menu->is_active ? 'success' : 'danger' }}">
                                            {{ $menu->is_active ? 'Activo' : 'Inactivo' }}
                                        </span>
                                    </td>
                                    <td>{{ $menu->order }}</td>
                                    <td>
                                        <div class="btn-group">
                                            <button type="button" class="btn btn-sm btn-info" data-toggle="modal" data-target="#editMenuModal{{ $menu->id }}">
                                                <i class="fas fa-edit"></i>
                                            </button>
                                            <button type="button" class="btn btn-sm btn-success" data-toggle="modal" data-target="#manageItemsModal{{ $menu->id }}">
                                                <i class="fas fa-list"></i>
                                            </button>
                                            <button type="button" class="btn btn-sm btn-danger" onclick="deleteMenu({{ $menu->id }})">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal para crear menú -->
<div class="modal fade" id="createMenuModal" tabindex="-1" role="dialog" aria-labelledby="createMenuModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="createMenuModalLabel">Crear Nuevo Menú</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="{{ route('admin.menus.store') }}" method="POST">
                @csrf
                <div class="modal-body">
                    <div class="form-group">
                        <label for="title">Título</label>
                        <input type="text" class="form-control" id="title" name="title" required>
                    </div>
                    <div class="form-group">
                        <label for="description">Descripción</label>
                        <textarea class="form-control" id="description" name="description" rows="3"></textarea>
                    </div>
                    <div class="form-group">
                        <label for="type">Tipo</label>
                        <select class="form-control" id="type" name="type" required>
                            <option value="button">Botón</option>
                            <option value="list">Lista</option>
                            <option value="text">Texto</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="content">Contenido</label>
                        <textarea class="form-control" id="content" name="content" rows="3" required></textarea>
                    </div>
                    <div class="form-group">
                        <label for="button_text">Texto del Botón</label>
                        <input type="text" class="form-control" id="button_text" name="button_text">
                    </div>
                    <div class="form-group">
                        <label for="icon">Icono</label>
                        <input type="text" class="form-control" id="icon" name="icon" placeholder="Ej: 🛍️">
                    </div>
                    <div class="form-group">
                        <label for="action_id">ID de Acción</label>
                        <input type="text" class="form-control" id="action_id" name="action_id" required>
                    </div>
                    <div class="form-group">
                        <label for="order">Orden</label>
                        <input type="number" class="form-control" id="order" name="order" value="0">
                    </div>
                    <div class="form-group">
                        <div class="custom-control custom-switch">
                            <input type="checkbox" class="custom-control-input" id="is_active" name="is_active" checked>
                            <label class="custom-control-label" for="is_active">Activo</label>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Guardar</button>
                </div>
            </form>
        </div>
    </div>
</div>

@foreach($menus as $menu)
<!-- Modal para editar menú -->
<div class="modal fade" id="editMenuModal{{ $menu->id }}" tabindex="-1" role="dialog" aria-labelledby="editMenuModalLabel{{ $menu->id }}" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editMenuModalLabel{{ $menu->id }}">Editar Menú</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="{{ route('admin.menus.update', $menu->id) }}" method="POST">
                @csrf
                @method('PUT')
                <div class="modal-body">
                    <div class="form-group">
                        <label for="title{{ $menu->id }}">Título</label>
                        <input type="text" class="form-control" id="title{{ $menu->id }}" name="title" value="{{ $menu->title }}" required>
                    </div>
                    <div class="form-group">
                        <label for="description{{ $menu->id }}">Descripción</label>
                        <textarea class="form-control" id="description{{ $menu->id }}" name="description" rows="3">{{ $menu->description }}</textarea>
                    </div>
                    <div class="form-group">
                        <label for="type{{ $menu->id }}">Tipo</label>
                        <select class="form-control" id="type{{ $menu->id }}" name="type" required>
                            <option value="button" {{ $menu->type === 'button' ? 'selected' : '' }}>Botón</option>
                            <option value="list" {{ $menu->type === 'list' ? 'selected' : '' }}>Lista</option>
                            <option value="text" {{ $menu->type === 'text' ? 'selected' : '' }}>Texto</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="content{{ $menu->id }}">Contenido</label>
                        <textarea class="form-control" id="content{{ $menu->id }}" name="content" rows="3" required>{{ $menu->content }}</textarea>
                    </div>
                    <div class="form-group">
                        <label for="button_text{{ $menu->id }}">Texto del Botón</label>
                        <input type="text" class="form-control" id="button_text{{ $menu->id }}" name="button_text" value="{{ $menu->button_text }}">
                    </div>
                    <div class="form-group">
                        <label for="icon{{ $menu->id }}">Icono</label>
                        <input type="text" class="form-control" id="icon{{ $menu->id }}" name="icon" value="{{ $menu->icon }}" placeholder="Ej: 🛍️">
                    </div>
                    <div class="form-group">
                        <label for="action_id{{ $menu->id }}">ID de Acción</label>
                        <input type="text" class="form-control" id="action_id{{ $menu->id }}" name="action_id" value="{{ $menu->action_id }}" required>
                    </div>
                    <div class="form-group">
                        <label for="order{{ $menu->id }}">Orden</label>
                        <input type="number" class="form-control" id="order{{ $menu->id }}" name="order" value="{{ $menu->order }}">
                    </div>
                    <div class="form-group">
                        <div class="custom-control custom-switch">
                            <input type="checkbox" class="custom-control-input" id="is_active{{ $menu->id }}" name="is_active" {{ $menu->is_active ? 'checked' : '' }}>
                            <label class="custom-control-label" for="is_active{{ $menu->id }}">Activo</label>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Guardar Cambios</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal para gestionar items -->
<div class="modal fade" id="manageItemsModal{{ $menu->id }}" tabindex="-1" role="dialog" aria-labelledby="manageItemsModalLabel{{ $menu->id }}" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="manageItemsModalLabel{{ $menu->id }}">Gestionar Items - {{ $menu->title }}</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <button type="button" class="btn btn-primary" onclick="showCreateItemModal({{ $menu->id }})">
                        <i class="fas fa-plus"></i> Nuevo Item
                    </button>
                </div>
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Título</th>
                                <th>Descripción</th>
                                <th>ID de Acción</th>
                                <th>Estado</th>
                                <th>Orden</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($menu->items as $item)
                            <tr>
                                <td>
                                    <i class="{{ $item->icon }}"></i>
                                    {{ $item->title }}
                                </td>
                                <td>{{ $item->description }}</td>
                                <td>{{ $item->action_id }}</td>
                                <td>
                                    <span class="badge badge-{{ $item->is_active ? 'success' : 'danger' }}">
                                        {{ $item->is_active ? 'Activo' : 'Inactivo' }}
                                    </span>
                                </td>
                                <td>{{ $item->order }}</td>
                                <td>
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-sm btn-info" onclick="editItem({{ $item->id }})">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button type="button" class="btn btn-sm btn-danger" onclick="deleteItem({{ $item->id }})">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endforeach

@endsection

@push('scripts')
<script>
function deleteMenu(id) {
    if (confirm('¿Estás seguro de que deseas eliminar este menú?')) {
        axios.delete(`/admin/menus/${id}`)
            .then(response => {
                window.location.reload();
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Ha ocurrido un error al eliminar el menú');
            });
    }
}

function deleteItem(id) {
    if (confirm('¿Estás seguro de que deseas eliminar este item?')) {
        axios.delete(`/admin/menu-items/${id}`)
            .then(response => {
                window.location.reload();
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Ha ocurrido un error al eliminar el item');
            });
    }
}

function showCreateItemModal(menuId) {
    // Implementar lógica para mostrar modal de creación de item
}

function editItem(itemId) {
    // Implementar lógica para editar item
}
</script>
@endpush
