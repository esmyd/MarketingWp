@extends('admin.layouts.app')

@section('header', 'Chats de Clientes')

@section('content')
<div class="bg-white shadow-sm rounded-lg overflow-hidden">
    <div class="p-6">
        <h2 class="text-xl font-semibold mb-4">Clientes con Conversaciones</h2>
        <ul class="divide-y divide-gray-200">
            @forelse($contacts as $contact)
                <li>
                    <a href="{{ route('admin.chat', $contact->id) }}" class="flex items-center py-4 hover:bg-gray-50 transition">
                        <div class="flex-1">
                            <span class="font-medium text-gray-900">{{ $contact->name ?? 'Cliente' }}</span>
                            <span class="ml-2 text-xs text-gray-500">{{ $contact->phone_number }}</span>
                        </div>
                        <span class="text-xs text-gray-400">{{ $contact->messages_count }} mensajes</span>
                        <i class="fas fa-chevron-right ml-4 text-gray-300"></i>
                    </a>
                </li>
            @empty
                <li class="py-8 text-center text-gray-400">No hay chats disponibles</li>
            @endforelse
        </ul>
    </div>
</div>
@endsection
