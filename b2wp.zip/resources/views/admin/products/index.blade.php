@extends('admin.layouts.app')

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Gestión de Productos y Precios</h3>
                    <div class="card-tools">
                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#createProductModal">
                            <i class="fas fa-plus"></i> Nuevo Producto
                        </button>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>SKU</th>
                                    <th>Nombre</th>
                                    <th>Categoría</th>
                                    <th>Precio</th>
                                    <th>Precio Promo</th>
                                    <th>Estado</th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($products as $product)
                                <tr>
                                    <td>{{ $product->sku }}</td>
                                    <td>
                                        <i class="{{ $product->icon }}"></i>
                                        {{ $product->name }}
                                    </td>
                                    <td>{{ $product->category }}</td>
                                    <td>${{ number_format($product->price, 2) }}</td>
                                    <td>
                                        @if($product->promo_price)
                                            ${{ number_format($product->promo_price, 2) }}
                                        @else
                                            -
                                        @endif
                                    </td>
                                    <td>
                                        <span class="badge badge-{{ $product->is_active ? 'success' : 'danger' }}">
                                            {{ $product->is_active ? 'Activo' : 'Inactivo' }}
                                        </span>
                                    </td>
                                    <td>
                                        <div class="btn-group">
                                            <button type="button" class="btn btn-sm btn-info" data-toggle="modal" data-target="#editProductModal{{ $product->id }}">
                                                <i class="fas fa-edit"></i>
                                            </button>
                                            <button type="button" class="btn btn-sm btn-success" data-toggle="modal" data-target="#viewDetailsModal{{ $product->id }}">
                                                <i class="fas fa-eye"></i>
                                            </button>
                                            <button type="button" class="btn btn-sm btn-danger" onclick="deleteProduct({{ $product->id }})">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal para crear producto -->
<div class="modal fade" id="createProductModal" tabindex="-1" role="dialog" aria-labelledby="createProductModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="createProductModalLabel">Crear Nuevo Producto</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="{{ route('admin.products.store') }}" method="POST">
                @csrf
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="sku">SKU</label>
                                <input type="text" class="form-control" id="sku" name="sku" required>
                            </div>
                            <div class="form-group">
                                <label for="name">Nombre</label>
                                <input type="text" class="form-control" id="name" name="name" required>
                            </div>
                            <div class="form-group">
                                <label for="category">Categoría</label>
                                <select class="form-control" id="category" name="category" required>
                                    @foreach($categories as $category)
                                        <option value="{{ $category->id }}">{{ $category->name }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="price">Precio</label>
                                <input type="number" class="form-control" id="price" name="price" step="0.01" required>
                            </div>
                            <div class="form-group">
                                <label for="promo_price">Precio Promocional</label>
                                <input type="number" class="form-control" id="promo_price" name="promo_price" step="0.01">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="description">Descripción</label>
                                <textarea class="form-control" id="description" name="description" rows="3"></textarea>
                            </div>
                            <div class="form-group">
                                <label for="benefits">Beneficios</label>
                                <textarea class="form-control" id="benefits" name="benefits" rows="3"></textarea>
                            </div>
                            <div class="form-group">
                                <label for="nutritional_info">Información Nutricional</label>
                                <textarea class="form-control" id="nutritional_info" name="nutritional_info" rows="3"></textarea>
                            </div>
                            <div class="form-group">
                                <label for="icon">Icono</label>
                                <input type="text" class="form-control" id="icon" name="icon" placeholder="Ej: 🥤">
                            </div>
                            <div class="form-group">
                                <div class="custom-control custom-switch">
                                    <input type="checkbox" class="custom-control-input" id="is_active" name="is_active" checked>
                                    <label class="custom-control-label" for="is_active">Activo</label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Guardar</button>
                </div>
            </form>
        </div>
    </div>
</div>

@foreach($products as $product)
<!-- Modal para editar producto -->
<div class="modal fade" id="editProductModal{{ $product->id }}" tabindex="-1" role="dialog" aria-labelledby="editProductModalLabel{{ $product->id }}" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editProductModalLabel{{ $product->id }}">Editar Producto</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="{{ route('admin.products.update', $product->id) }}" method="POST">
                @csrf
                @method('PUT')
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="sku{{ $product->id }}">SKU</label>
                                <input type="text" class="form-control" id="sku{{ $product->id }}" name="sku" value="{{ $product->sku }}" required>
                            </div>
                            <div class="form-group">
                                <label for="name{{ $product->id }}">Nombre</label>
                                <input type="text" class="form-control" id="name{{ $product->id }}" name="name" value="{{ $product->name }}" required>
                            </div>
                            <div class="form-group">
                                <label for="category{{ $product->id }}">Categoría</label>
                                <select class="form-control" id="category{{ $product->id }}" name="category" required>
                                    @foreach($categories as $category)
                                        <option value="{{ $category->id }}" {{ $product->category_id == $category->id ? 'selected' : '' }}>
                                            {{ $category->name }}
                                        </option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="price{{ $product->id }}">Precio</label>
                                <input type="number" class="form-control" id="price{{ $product->id }}" name="price" value="{{ $product->price }}" step="0.01" required>
                            </div>
                            <div class="form-group">
                                <label for="promo_price{{ $product->id }}">Precio Promocional</label>
                                <input type="number" class="form-control" id="promo_price{{ $product->id }}" name="promo_price" value="{{ $product->promo_price }}" step="0.01">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="description{{ $product->id }}">Descripción</label>
                                <textarea class="form-control" id="description{{ $product->id }}" name="description" rows="3">{{ $product->description }}</textarea>
                            </div>
                            <div class="form-group">
                                <label for="benefits{{ $product->id }}">Beneficios</label>
                                <textarea class="form-control" id="benefits{{ $product->id }}" name="benefits" rows="3">{{ $product->benefits }}</textarea>
                            </div>
                            <div class="form-group">
                                <label for="nutritional_info{{ $product->id }}">Información Nutricional</label>
                                <textarea class="form-control" id="nutritional_info{{ $product->id }}" name="nutritional_info" rows="3">{{ $product->nutritional_info }}</textarea>
                            </div>
                            <div class="form-group">
                                <label for="icon{{ $product->id }}">Icono</label>
                                <input type="text" class="form-control" id="icon{{ $product->id }}" name="icon" value="{{ $product->icon }}" placeholder="Ej: 🥤">
                            </div>
                            <div class="form-group">
                                <div class="custom-control custom-switch">
                                    <input type="checkbox" class="custom-control-input" id="is_active{{ $product->id }}" name="is_active" {{ $product->is_active ? 'checked' : '' }}>
                                    <label class="custom-control-label" for="is_active{{ $product->id }}">Activo</label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Guardar Cambios</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal para ver detalles -->
<div class="modal fade" id="viewDetailsModal{{ $product->id }}" tabindex="-1" role="dialog" aria-labelledby="viewDetailsModalLabel{{ $product->id }}" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="viewDetailsModalLabel{{ $product->id }}">Detalles del Producto</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-6">
                        <h6>Información Básica</h6>
                        <table class="table table-sm">
                            <tr>
                                <th>SKU:</th>
                                <td>{{ $product->sku }}</td>
                            </tr>
                            <tr>
                                <th>Nombre:</th>
                                <td>{{ $product->name }}</td>
                            </tr>
                            <tr>
                                <th>Categoría:</th>
                                <td>{{ $product->category->name }}</td>
                            </tr>
                            <tr>
                                <th>Precio:</th>
                                <td>${{ number_format($product->price, 2) }}</td>
                            </tr>
                            @if($product->promo_price)
                            <tr>
                                <th>Precio Promo:</th>
                                <td>${{ number_format($product->promo_price, 2) }}</td>
                            </tr>
                            @endif
                        </table>
                    </div>
                    <div class="col-md-6">
                        <h6>Detalles Adicionales</h6>
                        <table class="table table-sm">
                            <tr>
                                <th>Descripción:</th>
                                <td>{{ $product->description }}</td>
                            </tr>
                            <tr>
                                <th>Beneficios:</th>
                                <td>{{ $product->benefits }}</td>
                            </tr>
                            <tr>
                                <th>Info Nutricional:</th>
                                <td>{{ $product->nutritional_info }}</td>
                            </tr>
                            <tr>
                                <th>Estado:</th>
                                <td>
                                    <span class="badge badge-{{ $product->is_active ? 'success' : 'danger' }}">
                                        {{ $product->is_active ? 'Activo' : 'Inactivo' }}
                                    </span>
                                </td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
            </div>
        </div>
    </div>
</div>
@endforeach

@endsection

@push('scripts')
<script>
function deleteProduct(id) {
    if (confirm('¿Estás seguro de que deseas eliminar este producto?')) {
        axios.delete(`/admin/products/${id}`)
            .then(response => {
                window.location.reload();
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Ha ocurrido un error al eliminar el producto');
            });
    }
}
</script>
@endpush
