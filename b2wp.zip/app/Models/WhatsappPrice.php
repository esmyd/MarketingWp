<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class WhatsappPrice extends Model
{
    protected $fillable = [
        'menu_item_id',
        'sku',
        'name',
        'description',
        'benefits',
        'nutritional_info',
        'price',
        'promo_price',
        'icon',
        'is_active'
    ];

    protected $casts = [
        'price' => 'decimal:2',
        'promo_price' => 'decimal:2',
        'is_active' => 'boolean'
    ];

    public function category(): BelongsTo
    {
        return $this->belongsTo(WhatsappMenu::class, 'menu_item_id');
    }
}
