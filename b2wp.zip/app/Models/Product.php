<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    protected $fillable = [
        'name',
        'description',
        'price',
        'category',
        'stock',
        'image_url',
        'is_active',
        'metadata'
    ];

    protected $casts = [
        'price' => 'float',
        'stock' => 'integer',
        'is_active' => 'boolean',
        'metadata' => 'array'
    ];

    public function getFormattedPriceAttribute()
    {
        return '$' . number_format($this->price, 2);
    }

    public function getStockStatusAttribute()
    {
        if ($this->stock > 10) {
            return 'Disponible';
        } elseif ($this->stock > 0) {
            return 'Últimas unidades';
        } else {
            return 'Agotado';
        }
    }

    public static function getByCategory($category)
    {
        return static::where('category', $category)
            ->where('is_active', true)
            ->orderBy('name')
            ->get();
    }

    public static function getFeaturedProducts()
    {
        return static::where('is_active', true)
            ->where('stock', '>', 0)
            ->orderBy('created_at', 'desc')
            ->take(5)
            ->get();
    }
}
