<?php $__env->startSection('header'); ?>
<!-- Include Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Stats Grid -->
<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-6">
    <div class="bg-white rounded-lg shadow-sm p-6">
        <div class="stat-title text-gray-600 flex items-center">Total Mensajes
            <span class="ml-2 cursor-pointer" title="Cantidad total de mensajes enviados y recibidos en el sistema (tabla whatsapp_messages)">ℹ️</span>
        </div>
        <div class="stat-value text-2xl font-bold text-gray-800">
            <?php echo e($totalMessages > 0 ? number_format($totalMessages) : 'Sin datos'); ?>

        </div>
        <div class="stat-change text-sm <?php echo e($messageGrowth >= 0 ? 'text-green-600' : 'text-red-600'); ?>">
            <?php echo e($messageGrowth >= 0 ? '+' : ''); ?><?php echo e(number_format($messageGrowth, 1)); ?>% vs mes anterior
        </div>
    </div>
    <div class="bg-white rounded-lg shadow-sm p-6">
        <div class="stat-title text-gray-600 flex items-center">Tasa de Respuesta
            <span class="ml-2 cursor-pointer" title="Porcentaje de mensajes de clientes que recibieron respuesta del sistema en el periodo (tabla whatsapp_messages)">ℹ️</span>
        </div>
        <div class="stat-value text-2xl font-bold text-gray-800">
            <?php echo e($responseRate > 0 ? number_format($responseRate, 1) . '%' : 'Sin datos'); ?>

        </div>
        <div class="stat-change text-sm <?php echo e($responseRateGrowth >= 0 ? 'text-green-600' : 'text-red-600'); ?>">
            <?php echo e($responseRateGrowth >= 0 ? '+' : ''); ?><?php echo e(number_format($responseRateGrowth, 1)); ?>% vs mes anterior
        </div>
    </div>
    <div class="bg-white rounded-lg shadow-sm p-6">
        <div class="stat-title text-gray-600 flex items-center">Tiempo Promedio Respuesta
            <span class="ml-2 cursor-pointer" title="Promedio de minutos que tarda el sistema en responder a un mensaje de cliente (calculado por diferencia de timestamps en whatsapp_messages)">ℹ️</span>
        </div>
        <div class="stat-value text-2xl font-bold text-gray-800">
            <?php
                $min = $avgResponseTime;
                if($min > 0) {
                    $h = floor($min / 60);
                    $m = round($min % 60);
                    echo $h > 0 ? "$h h $m m" : "$m m";
                } else {
                    echo 'Sin datos';
                }
            ?>
        </div>
        <div class="stat-change text-sm <?php echo e($responseTimeGrowth >= 0 ? 'text-green-600' : 'text-red-600'); ?>">
            <?php echo e($responseTimeGrowth >= 0 ? '+' : ''); ?><?php echo e(number_format($responseTimeGrowth, 1)); ?>% vs mes anterior
        </div>
    </div>
    <div class="bg-white rounded-lg shadow-sm p-6">
        <div class="stat-title text-gray-600 flex items-center">Clientes Activos
            <span class="ml-2 cursor-pointer" title="Cantidad de contactos únicos que han enviado o recibido al menos un mensaje en los últimos 30 días (tabla whatsapp_messages)">ℹ️</span>
        </div>
        <div class="stat-value text-2xl font-bold text-gray-800">
            <?php echo e($activeClients > 0 ? number_format($activeClients) : 'Sin datos'); ?>

        </div>
        <div class="stat-change text-sm <?php echo e($activeClientsGrowth >= 0 ? 'text-green-600' : 'text-red-600'); ?>">
            <?php echo e($activeClientsGrowth >= 0 ? '+' : ''); ?><?php echo e(number_format($activeClientsGrowth, 1)); ?>% vs mes anterior
        </div>
    </div>
    <div class="bg-white rounded-lg shadow-sm p-6">
        <div class="stat-title text-gray-600 flex items-center">Tasa de Interacción
            <span class="ml-2 cursor-pointer" title="Porcentaje de mensajes enviados por el sistema que recibieron respuesta del cliente (tabla whatsapp_messages)">ℹ️</span>
        </div>
        <div class="stat-value text-2xl font-bold text-gray-800">
            <?php echo e($interactionRate > 0 ? number_format($interactionRate, 1) . '%' : 'Sin datos'); ?>

        </div>
        <div class="stat-change text-sm <?php echo e($interactionRateGrowth >= 0 ? 'text-green-600' : 'text-red-600'); ?>">
            <?php echo e($interactionRateGrowth >= 0 ? '+' : ''); ?><?php echo e(number_format($interactionRateGrowth, 1)); ?>% vs mes anterior
        </div>
    </div>
</div>

<!-- Indicadores personalizados -->
<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-6">
    <div class="bg-white rounded-lg shadow-sm p-6">
        <div class="stat-title text-gray-600 flex items-center">Clientes nuevos este mes
            <span class="ml-2 cursor-pointer" title="Cantidad de clientes registrados en el mes actual (según fecha de creación en whatsapp_contacts)">ℹ️</span>
        </div>
        <div class="stat-value text-2xl font-bold text-gray-800">
            <?php echo e($newClientsThisMonth > 0 ? number_format($newClientsThisMonth) : 'Sin datos'); ?>

        </div>
    </div>
    <div class="bg-white rounded-lg shadow-sm p-6">
        <div class="stat-title text-gray-600 flex items-center">Pedidos este mes
            <span class="ml-2 cursor-pointer" title="Cantidad de carritos completados (status 'completed') en el mes actual (tabla whatsapp_carts)">ℹ️</span>
        </div>
        <div class="stat-value text-2xl font-bold text-gray-800">
            <?php echo e($ordersThisMonth > 0 ? number_format($ordersThisMonth) : 'Sin datos'); ?>

        </div>
    </div>
    <div class="bg-white rounded-lg shadow-sm p-6">
        <div class="stat-title text-gray-600 flex items-center">Imágenes enviadas este mes
            <span class="ml-2 cursor-pointer" title="Cantidad de mensajes de tipo 'image' enviados este mes (tabla whatsapp_messages)">ℹ️</span>
        </div>
        <div class="stat-value text-2xl font-bold text-gray-800">
            <?php echo e($topImages && $topImages->total > 0 ? number_format($topImages->total) : 'Sin datos'); ?>

        </div>
    </div>
</div>

<!-- Charts Grid -->
<div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
    <!-- Messages Activity Chart -->
    <div class="bg-white rounded-lg shadow-sm p-6">
        <h3 class="text-lg font-semibold mb-4">Actividad de Mensajes</h3>
        <div style="height: 300px; position: relative;">
            <canvas id="messagesChart"></canvas>
        </div>
    </div>

    <!-- Response Time Chart -->
    <div class="bg-white rounded-lg shadow-sm p-6">
        <h3 class="text-lg font-semibold mb-4">Tiempo de Respuesta</h3>
        <div style="height: 300px; position: relative;">
            <canvas id="responseTimeChart"></canvas>
        </div>
    </div>

    <!-- Message Types Chart -->
    <div class="bg-white rounded-lg shadow-sm p-6">
        <h3 class="text-lg font-semibold mb-4">Distribución de Tipos de Mensajes</h3>
        <div style="height: 300px; position: relative;">
            <canvas id="messageTypesChart"></canvas>
        </div>
    </div>

    <!-- Topics Distribution Chart -->
    <div class="bg-white rounded-lg shadow-sm p-6">
        <h3 class="text-lg font-semibold mb-4">Distribución de Temas</h3>
        <div style="height: 300px; position: relative;">
            <canvas id="topicsChart"></canvas>
        </div>
    </div>
</div>

<!-- Top productos y opciones -->
<div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
    <div class="bg-white rounded-lg shadow-sm p-6">
        <h3 class="text-lg font-semibold mb-4 flex items-center">Productos más pedidos (mes)
            <span class="ml-2 cursor-pointer" title="Top 5 productos más pedidos este mes, sumando la cantidad de whatsapp_cart_items por nombre.">ℹ️</span>
        </h3>
        <ul>
            <?php $__empty_1 = true; $__currentLoopData = $topProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <li class="flex justify-between border-b py-2">
                    <span><?php echo e($prod->name); ?></span>
                    <span class="font-bold"><?php echo e($prod->total); ?></span>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <li class="text-gray-500">Sin datos</li>
            <?php endif; ?>
        </ul>
    </div>
    <div class="bg-white rounded-lg shadow-sm p-6">
        <h3 class="text-lg font-semibold mb-4 flex items-center">Opciones más consultadas (mes)
            <span class="ml-2 cursor-pointer" title="Top 5 tipos de mensajes más consultados este mes (campo 'type' en whatsapp_messages)">ℹ️</span>
        </h3>
        <ul>
            <?php $__empty_1 = true; $__currentLoopData = $topOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <li class="flex justify-between border-b py-2">
                    <span><?php echo e($opt->type); ?></span>
                    <span class="font-bold"><?php echo e($opt->total); ?></span>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <li class="text-gray-500">Sin datos</li>
            <?php endif; ?>
        </ul>
    </div>
</div>

<!-- Mensajes por hora (gráfico) -->
<div class="bg-white rounded-lg shadow-sm p-6 mb-6">
    <h3 class="text-lg font-semibold mb-4 flex items-center">Mensajes por hora (mes actual)
        <span class="ml-2 cursor-pointer" title="Cantidad de mensajes enviados agrupados por hora del día en el mes actual (tabla whatsapp_messages)">ℹ️</span>
    </h3>
    <div style="height: 300px; position: relative;">
        <canvas id="messagesByHourChart"></canvas>
    </div>
</div>

<!-- Recent Activity Grid -->
<div class="grid grid-cols-1 md:grid-cols-2 gap-6">
    <!-- Orders Summary -->
    <div class="bg-white rounded-lg shadow-sm">
        <div class="p-6">
            <h2 class="text-xl font-semibold mb-4">Últimos Pedidos</h2>
            <div class="space-y-4">
                <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="border-b pb-4">
                        <div class="flex justify-between items-center">
                            <div>
                                <p class="font-medium"><?php echo e($order->contact->name ?? 'Cliente'); ?></p>
                                <p class="text-sm text-gray-600"><?php echo e($order->created_at->format('d/m/Y H:i')); ?></p>
                            </div>
                            <span class="px-3 py-1 rounded-full text-sm <?php echo e($order->status === 'completed' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'); ?>">
                                <?php echo e($order->status); ?>

                            </span>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-gray-500">No hay pedidos recientes</p>
                <?php endif; ?>
            </div>
            <a href="<?php echo e(route('admin.orders')); ?>" class="mt-4 inline-block text-blue-600 hover:text-blue-800">Ver todos los pedidos →</a>
        </div>
    </div>

    <!-- Messages Summary -->
    <div class="bg-white rounded-lg shadow-sm">
        <div class="p-6">
            <h2 class="text-xl font-semibold mb-4">Últimos Mensajes</h2>
            <div class="space-y-4">
                <?php $__empty_1 = true; $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="border-b pb-4">
                        <div class="flex justify-between items-center">
                            <div>
                                <p class="font-medium"><?php echo e($message->contact->name ?? 'Cliente'); ?></p>
                                <?php
                                    $content = $message->content;
                                    $decoded = null;
                                    try {
                                        $decoded = json_decode($content, true, 512, JSON_THROW_ON_ERROR);
                                    } catch (\Throwable $e) {
                                        $decoded = null;
                                    }
                                ?>
                                <?php if(is_array($decoded) && isset($decoded['title'])): ?>
                                    <p class="text-sm text-gray-800 font-semibold"><?php echo e($decoded['title']); ?></p>
                                    <?php if(isset($decoded['description'])): ?>
                                        <p class="text-xs text-gray-600"><?php echo e(\Illuminate\Support\Str::limit($decoded['description'], 80)); ?></p>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <p class="text-sm text-gray-600 truncate max-w-md"><?php echo e(\Illuminate\Support\Str::limit($content, 80)); ?></p>
                                <?php endif; ?>
                                <p class="text-xs text-gray-500"><?php echo e($message->created_at->format('d/m/Y H:i')); ?></p>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-gray-500">No hay mensajes recientes</p>
                <?php endif; ?>
            </div>
            <a href="<?php echo e(route('admin.messages')); ?>" class="mt-4 inline-block text-blue-600 hover:text-blue-800">Ver todos los mensajes →</a>
        </div>
    </div>
</div>

<!-- Top Topics Section -->
<div class="bg-white rounded-lg shadow-sm mt-6">
    <div class="p-6">
        <h3 class="text-lg font-semibold mb-4">Temas más Frecuentes</h3>
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <?php $__currentLoopData = $topTopics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="bg-gray-50 rounded-lg p-4">
                <div class="flex justify-between items-center">
                    <span class="font-medium text-gray-800"><?php echo e($topic['name']); ?></span>
                    <span class="bg-blue-100 text-blue-800 text-sm px-3 py-1 rounded-full"><?php echo e($topic['count']); ?></span>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Configuración común para todos los gráficos
    const commonOptions = {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                position: 'top',
            }
        }
    };

    // Messages Activity Chart
    const messagesCtx = document.getElementById('messagesChart').getContext('2d');
    new Chart(messagesCtx, {
        type: 'line',
        data: {
            labels: <?php echo json_encode($messagesData->pluck('date')); ?>,
            datasets: [{
                label: 'Mensajes Enviados',
                data: <?php echo json_encode($messagesData->pluck('sent')); ?>,
                borderColor: '#25d366',
                tension: 0.4,
                fill: false
            }, {
                label: 'Mensajes Recibidos',
                data: <?php echo json_encode($messagesData->pluck('received')); ?>,
                borderColor: '#128C7E',
                tension: 0.4,
                fill: false
            }]
        },
        options: {
            ...commonOptions,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        precision: 0
                    }
                }
            }
        }
    });

    // Response Time Chart
    const responseCtx = document.getElementById('responseTimeChart').getContext('2d');
    new Chart(responseCtx, {
        type: 'bar',
        data: {
            labels: <?php echo json_encode($responseTimeData->pluck('date')); ?>,
            datasets: [{
                label: 'Tiempo de Respuesta (min)',
                data: <?php echo json_encode($responseTimeData->pluck('avg_time')); ?>,
                backgroundColor: '#25d366'
            }]
        },
        options: {
            ...commonOptions,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        precision: 1
                    }
                }
            }
        }
    });

    // Message Types Chart
    const messageTypesCtx = document.getElementById('messageTypesChart').getContext('2d');
    new Chart(messageTypesCtx, {
        type: 'doughnut',
        data: {
            labels: ['Texto', 'Botones', 'Listas', 'Imágenes'],
            datasets: [{
                data: [45, 25, 20, 10],
                backgroundColor: [
                    '#25d366',
                    '#128C7E',
                    '#34B7F1',
                    '#075E54'
                ]
            }]
        },
        options: {
            ...commonOptions,
            cutout: '60%'
        }
    });

    // Topics Distribution Chart
    const topicsCtx = document.getElementById('topicsChart').getContext('2d');
    new Chart(topicsCtx, {
        type: 'bar',
        data: {
            labels: <?php echo json_encode($topTopics->pluck('name')); ?>,
            datasets: [{
                label: 'Mensajes por Tema',
                data: <?php echo json_encode($topTopics->pluck('count')); ?>,
                backgroundColor: '#25d366'
            }]
        },
        options: {
            ...commonOptions,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        precision: 0
                    }
                }
            },
            indexAxis: 'y'
        }
    });

    // Mensajes por hora (nuevo gráfico)
    const messagesByHourCtx = document.getElementById('messagesByHourChart').getContext('2d');
    new Chart(messagesByHourCtx, {
        type: 'bar',
        data: {
            labels: <?php echo json_encode($messagesByHour->pluck('hour')); ?>,
            datasets: [{
                label: 'Mensajes',
                data: <?php echo json_encode($messagesByHour->pluck('total')); ?>,
                backgroundColor: '#128C7E'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: { precision: 0 }
                }
            }
        }
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programas\Laragon\laragon\www\WhatsApp\MarketingWp\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>