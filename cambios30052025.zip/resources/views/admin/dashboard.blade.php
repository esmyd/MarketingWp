@extends('admin.layouts.app')

@section('header')
<!-- Include Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
@endsection

@section('content')
<!-- Stats Grid -->
<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-6">
    <div class="bg-white rounded-lg shadow-sm p-6">
        <div class="stat-title text-gray-600 flex items-center">Total Mensajes
            <span class="ml-2 cursor-pointer" title="Cantidad total de mensajes enviados y recibidos en el sistema (tabla whatsapp_messages)">ℹ️</span>
        </div>
        <div class="stat-value text-2xl font-bold text-gray-800">
            {{ $totalMessages > 0 ? number_format($totalMessages) : 'Sin datos' }}
        </div>
        <div class="stat-change text-sm {{ $messageGrowth >= 0 ? 'text-green-600' : 'text-red-600' }}">
            {{ $messageGrowth >= 0 ? '+' : '' }}{{ number_format($messageGrowth, 1) }}% vs mes anterior
        </div>
    </div>
    <div class="bg-white rounded-lg shadow-sm p-6">
        <div class="stat-title text-gray-600 flex items-center">Tasa de Respuesta
            <span class="ml-2 cursor-pointer" title="Porcentaje de mensajes de clientes que recibieron respuesta del sistema en el periodo (tabla whatsapp_messages)">ℹ️</span>
        </div>
        <div class="stat-value text-2xl font-bold text-gray-800">
            {{ $responseRate > 0 ? number_format($responseRate, 1) . '%' : 'Sin datos' }}
        </div>
        <div class="stat-change text-sm {{ $responseRateGrowth >= 0 ? 'text-green-600' : 'text-red-600' }}">
            {{ $responseRateGrowth >= 0 ? '+' : '' }}{{ number_format($responseRateGrowth, 1) }}% vs mes anterior
        </div>
    </div>
    <div class="bg-white rounded-lg shadow-sm p-6">
        <div class="stat-title text-gray-600 flex items-center">Tiempo Promedio Respuesta
            <span class="ml-2 cursor-pointer" title="Promedio de minutos que tarda el sistema en responder a un mensaje de cliente (calculado por diferencia de timestamps en whatsapp_messages)">ℹ️</span>
        </div>
        <div class="stat-value text-2xl font-bold text-gray-800">
            @php
                $min = $avgResponseTime;
                if($min > 0) {
                    $h = floor($min / 60);
                    $m = round($min % 60);
                    echo $h > 0 ? "$h h $m m" : "$m m";
                } else {
                    echo 'Sin datos';
                }
            @endphp
        </div>
        <div class="stat-change text-sm {{ $responseTimeGrowth >= 0 ? 'text-green-600' : 'text-red-600' }}">
            {{ $responseTimeGrowth >= 0 ? '+' : '' }}{{ number_format($responseTimeGrowth, 1) }}% vs mes anterior
        </div>
    </div>
    <div class="bg-white rounded-lg shadow-sm p-6">
        <div class="stat-title text-gray-600 flex items-center">Clientes Activos
            <span class="ml-2 cursor-pointer" title="Cantidad de contactos únicos que han enviado o recibido al menos un mensaje en los últimos 30 días (tabla whatsapp_messages)">ℹ️</span>
        </div>
        <div class="stat-value text-2xl font-bold text-gray-800">
            {{ $activeClients > 0 ? number_format($activeClients) : 'Sin datos' }}
        </div>
        <div class="stat-change text-sm {{ $activeClientsGrowth >= 0 ? 'text-green-600' : 'text-red-600' }}">
            {{ $activeClientsGrowth >= 0 ? '+' : '' }}{{ number_format($activeClientsGrowth, 1) }}% vs mes anterior
        </div>
    </div>
    <div class="bg-white rounded-lg shadow-sm p-6">
        <div class="stat-title text-gray-600 flex items-center">Tasa de Interacción
            <span class="ml-2 cursor-pointer" title="Porcentaje de mensajes enviados por el sistema que recibieron respuesta del cliente (tabla whatsapp_messages)">ℹ️</span>
        </div>
        <div class="stat-value text-2xl font-bold text-gray-800">
            {{ $interactionRate > 0 ? number_format($interactionRate, 1) . '%' : 'Sin datos' }}
        </div>
        <div class="stat-change text-sm {{ $interactionRateGrowth >= 0 ? 'text-green-600' : 'text-red-600' }}">
            {{ $interactionRateGrowth >= 0 ? '+' : '' }}{{ number_format($interactionRateGrowth, 1) }}% vs mes anterior
        </div>
    </div>
</div>

<!-- Indicadores personalizados -->
<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-6">
    <div class="bg-white rounded-lg shadow-sm p-6">
        <div class="stat-title text-gray-600 flex items-center">Clientes nuevos este mes
            <span class="ml-2 cursor-pointer" title="Cantidad de clientes registrados en el mes actual (según fecha de creación en whatsapp_contacts)">ℹ️</span>
        </div>
        <div class="stat-value text-2xl font-bold text-gray-800">
            {{ $newClientsThisMonth > 0 ? number_format($newClientsThisMonth) : 'Sin datos' }}
        </div>
    </div>
    <div class="bg-white rounded-lg shadow-sm p-6">
        <div class="stat-title text-gray-600 flex items-center">Pedidos este mes
            <span class="ml-2 cursor-pointer" title="Cantidad de carritos completados (status 'completed') en el mes actual (tabla whatsapp_carts)">ℹ️</span>
        </div>
        <div class="stat-value text-2xl font-bold text-gray-800">
            {{ $ordersThisMonth > 0 ? number_format($ordersThisMonth) : 'Sin datos' }}
        </div>
    </div>
    <div class="bg-white rounded-lg shadow-sm p-6">
        <div class="stat-title text-gray-600 flex items-center">Imágenes enviadas este mes
            <span class="ml-2 cursor-pointer" title="Cantidad de mensajes de tipo 'image' enviados este mes (tabla whatsapp_messages)">ℹ️</span>
        </div>
        <div class="stat-value text-2xl font-bold text-gray-800">
            {{ $topImages && $topImages->total > 0 ? number_format($topImages->total) : 'Sin datos' }}
        </div>
    </div>
</div>

<!-- Charts Grid -->
<div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
    <!-- Messages Activity Chart -->
    <div class="bg-white rounded-lg shadow-sm p-6">
        <h3 class="text-lg font-semibold mb-4">Actividad de Mensajes</h3>
        <div style="height: 300px; position: relative;">
            <canvas id="messagesChart"></canvas>
        </div>
    </div>

    <!-- Response Time Chart -->
    <div class="bg-white rounded-lg shadow-sm p-6">
        <h3 class="text-lg font-semibold mb-4">Tiempo de Respuesta</h3>
        <div style="height: 300px; position: relative;">
            <canvas id="responseTimeChart"></canvas>
        </div>
    </div>

    <!-- Message Types Chart -->
    <div class="bg-white rounded-lg shadow-sm p-6">
        <h3 class="text-lg font-semibold mb-4">Distribución de Tipos de Mensajes</h3>
        <div style="height: 300px; position: relative;">
            <canvas id="messageTypesChart"></canvas>
        </div>
    </div>

    <!-- Topics Distribution Chart -->
    <div class="bg-white rounded-lg shadow-sm p-6">
        <h3 class="text-lg font-semibold mb-4">Distribución de Temas</h3>
        <div style="height: 300px; position: relative;">
            <canvas id="topicsChart"></canvas>
        </div>
    </div>
</div>

<!-- Top productos y opciones -->
<div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
    <div class="bg-white rounded-lg shadow-sm p-6">
        <h3 class="text-lg font-semibold mb-4 flex items-center">Productos más pedidos (mes)
            <span class="ml-2 cursor-pointer" title="Top 5 productos más pedidos este mes, sumando la cantidad de whatsapp_cart_items por nombre.">ℹ️</span>
        </h3>
        <ul>
            @forelse($topProducts as $prod)
                <li class="flex justify-between border-b py-2">
                    <span>{{ $prod->name }}</span>
                    <span class="font-bold">{{ $prod->total }}</span>
                </li>
            @empty
                <li class="text-gray-500">Sin datos</li>
            @endforelse
        </ul>
    </div>
    <div class="bg-white rounded-lg shadow-sm p-6">
        <h3 class="text-lg font-semibold mb-4 flex items-center">Opciones más consultadas (mes)
            <span class="ml-2 cursor-pointer" title="Top 5 tipos de mensajes más consultados este mes (campo 'type' en whatsapp_messages)">ℹ️</span>
        </h3>
        <ul>
            @forelse($topOptions as $opt)
                <li class="flex justify-between border-b py-2">
                    <span>{{ $opt->type }}</span>
                    <span class="font-bold">{{ $opt->total }}</span>
                </li>
            @empty
                <li class="text-gray-500">Sin datos</li>
            @endforelse
        </ul>
    </div>
</div>

<!-- Mensajes por hora (gráfico) -->
<div class="bg-white rounded-lg shadow-sm p-6 mb-6">
    <h3 class="text-lg font-semibold mb-4 flex items-center">Mensajes por hora (mes actual)
        <span class="ml-2 cursor-pointer" title="Cantidad de mensajes enviados agrupados por hora del día en el mes actual (tabla whatsapp_messages)">ℹ️</span>
    </h3>
    <div style="height: 300px; position: relative;">
        <canvas id="messagesByHourChart"></canvas>
    </div>
</div>

<!-- Recent Activity Grid -->
<div class="grid grid-cols-1 md:grid-cols-2 gap-6">
    <!-- Orders Summary -->
    <div class="bg-white rounded-lg shadow-sm">
        <div class="p-6">
            <h2 class="text-xl font-semibold mb-4">Últimos Pedidos</h2>
            <div class="space-y-4">
                @forelse($orders as $order)
                    <div class="border-b pb-4">
                        <div class="flex justify-between items-center">
                            <div>
                                <p class="font-medium">{{ $order->contact->name ?? 'Cliente' }}</p>
                                <p class="text-sm text-gray-600">{{ $order->created_at->format('d/m/Y H:i') }}</p>
                            </div>
                            <span class="px-3 py-1 rounded-full text-sm {{ $order->status === 'completed' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800' }}">
                                {{ $order->status }}
                            </span>
                        </div>
                    </div>
                @empty
                    <p class="text-gray-500">No hay pedidos recientes</p>
                @endforelse
            </div>
            <a href="{{ route('admin.orders') }}" class="mt-4 inline-block text-blue-600 hover:text-blue-800">Ver todos los pedidos →</a>
        </div>
    </div>

    <!-- Messages Summary -->
    <div class="bg-white rounded-lg shadow-sm">
        <div class="p-6">
            <h2 class="text-xl font-semibold mb-4">Últimos Mensajes</h2>
            <div class="space-y-4">
                @forelse($messages as $message)
                    <div class="border-b pb-4">
                        <div class="flex justify-between items-center">
                            <div>
                                <p class="font-medium">{{ $message->contact->name ?? 'Cliente' }}</p>
                                @php
                                    $content = $message->content;
                                    $decoded = null;
                                    try {
                                        $decoded = json_decode($content, true, 512, JSON_THROW_ON_ERROR);
                                    } catch (\Throwable $e) {
                                        $decoded = null;
                                    }
                                @endphp
                                @if(is_array($decoded) && isset($decoded['title']))
                                    <p class="text-sm text-gray-800 font-semibold">{{ $decoded['title'] }}</p>
                                    @if(isset($decoded['description']))
                                        <p class="text-xs text-gray-600">{{ \Illuminate\Support\Str::limit($decoded['description'], 80) }}</p>
                                    @endif
                                @else
                                    <p class="text-sm text-gray-600 truncate max-w-md">{{ \Illuminate\Support\Str::limit($content, 80) }}</p>
                                @endif
                                <p class="text-xs text-gray-500">{{ $message->created_at->format('d/m/Y H:i') }}</p>
                            </div>
                        </div>
                    </div>
                @empty
                    <p class="text-gray-500">No hay mensajes recientes</p>
                @endforelse
            </div>
            <a href="{{ route('admin.messages') }}" class="mt-4 inline-block text-blue-600 hover:text-blue-800">Ver todos los mensajes →</a>
        </div>
    </div>
</div>

<!-- Top Topics Section -->
<div class="bg-white rounded-lg shadow-sm mt-6">
    <div class="p-6">
        <h3 class="text-lg font-semibold mb-4">Temas más Frecuentes</h3>
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            @foreach($topTopics as $topic)
            <div class="bg-gray-50 rounded-lg p-4">
                <div class="flex justify-between items-center">
                    <span class="font-medium text-gray-800">{{ $topic['name'] }}</span>
                    <span class="bg-blue-100 text-blue-800 text-sm px-3 py-1 rounded-full">{{ $topic['count'] }}</span>
                </div>
            </div>
            @endforeach
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Configuración común para todos los gráficos
    const commonOptions = {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                position: 'top',
            }
        }
    };

    // Messages Activity Chart
    const messagesCtx = document.getElementById('messagesChart').getContext('2d');
    new Chart(messagesCtx, {
        type: 'line',
        data: {
            labels: {!! json_encode($messagesData->pluck('date')) !!},
            datasets: [{
                label: 'Mensajes Enviados',
                data: {!! json_encode($messagesData->pluck('sent')) !!},
                borderColor: '#25d366',
                tension: 0.4,
                fill: false
            }, {
                label: 'Mensajes Recibidos',
                data: {!! json_encode($messagesData->pluck('received')) !!},
                borderColor: '#128C7E',
                tension: 0.4,
                fill: false
            }]
        },
        options: {
            ...commonOptions,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        precision: 0
                    }
                }
            }
        }
    });

    // Response Time Chart
    const responseCtx = document.getElementById('responseTimeChart').getContext('2d');
    new Chart(responseCtx, {
        type: 'bar',
        data: {
            labels: {!! json_encode($responseTimeData->pluck('date')) !!},
            datasets: [{
                label: 'Tiempo de Respuesta (min)',
                data: {!! json_encode($responseTimeData->pluck('avg_time')) !!},
                backgroundColor: '#25d366'
            }]
        },
        options: {
            ...commonOptions,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        precision: 1
                    }
                }
            }
        }
    });

    // Message Types Chart
    const messageTypesCtx = document.getElementById('messageTypesChart').getContext('2d');
    new Chart(messageTypesCtx, {
        type: 'doughnut',
        data: {
            labels: ['Texto', 'Botones', 'Listas', 'Imágenes'],
            datasets: [{
                data: [45, 25, 20, 10],
                backgroundColor: [
                    '#25d366',
                    '#128C7E',
                    '#34B7F1',
                    '#075E54'
                ]
            }]
        },
        options: {
            ...commonOptions,
            cutout: '60%'
        }
    });

    // Topics Distribution Chart
    const topicsCtx = document.getElementById('topicsChart').getContext('2d');
    new Chart(topicsCtx, {
        type: 'bar',
        data: {
            labels: {!! json_encode($topTopics->pluck('name')) !!},
            datasets: [{
                label: 'Mensajes por Tema',
                data: {!! json_encode($topTopics->pluck('count')) !!},
                backgroundColor: '#25d366'
            }]
        },
        options: {
            ...commonOptions,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        precision: 0
                    }
                }
            },
            indexAxis: 'y'
        }
    });

    // Mensajes por hora (nuevo gráfico)
    const messagesByHourCtx = document.getElementById('messagesByHourChart').getContext('2d');
    new Chart(messagesByHourCtx, {
        type: 'bar',
        data: {
            labels: {!! json_encode($messagesByHour->pluck('hour')) !!},
            datasets: [{
                label: 'Mensajes',
                data: {!! json_encode($messagesByHour->pluck('total')) !!},
                backgroundColor: '#128C7E'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: { precision: 0 }
                }
            }
        }
    });
});
</script>
@endsection
