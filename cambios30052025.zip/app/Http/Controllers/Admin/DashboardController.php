<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\WhatsappMessage;
use App\Models\WhatsappContact;
use App\Models\WhatsappConversation;
use App\Models\Order;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{
    public function index()
    {
        // Período actual (últimos 30 días)
        $now = Carbon::now();
        $thirtyDaysAgo = $now->copy()->subDays(30);
        $sixtyDaysAgo = $now->copy()->subDays(60);

        // Total de mensajes
        $totalMessages = WhatsappMessage::count();
        $lastMonthMessages = WhatsappMessage::where('created_at', '>=', $thirtyDaysAgo)->count();
        $previousMonthMessages = WhatsappMessage::whereBetween('created_at', [$sixtyDaysAgo, $thirtyDaysAgo])->count();
        $messageGrowth = $previousMonthMessages > 0
            ? (($lastMonthMessages - $previousMonthMessages) / $previousMonthMessages) * 100
            : 0;

        // Tasa de respuesta
        $totalResponses = WhatsappMessage::where('sender_type', 'system')
            ->where('created_at', '>=', $thirtyDaysAgo)
            ->count();
        $totalInbound = WhatsappMessage::where('sender_type', 'client')
            ->where('created_at', '>=', $thirtyDaysAgo)
            ->count();
        $responseRate = $totalInbound > 0 ? ($totalResponses / $totalInbound) * 100 : 0;

        $previousResponses = WhatsappMessage::where('sender_type', 'system')
            ->whereBetween('created_at', [$sixtyDaysAgo, $thirtyDaysAgo])
            ->count();
        $previousInbound = WhatsappMessage::where('sender_type', 'client')
            ->whereBetween('created_at', [$sixtyDaysAgo, $thirtyDaysAgo])
            ->count();
        $previousResponseRate = $previousInbound > 0 ? ($previousResponses / $previousInbound) * 100 : 0;
        $responseRateGrowth = $previousResponseRate > 0
            ? (($responseRate - $previousResponseRate) / $previousResponseRate) * 100
            : 0;

        // Tiempo promedio de respuesta usando subconsulta
        $avgResponseTime = DB::table('whatsapp_messages as wm1')
            ->join('whatsapp_messages as wm2', function($join) {
                $join->on('wm1.contact_id', '=', 'wm2.contact_id')
                    ->where('wm2.created_at', '<', DB::raw('wm1.created_at'))
                    ->where('wm2.sender_type', '=', 'client');
            })
            ->where('wm1.sender_type', 'system')
            ->where('wm1.created_at', '>=', $thirtyDaysAgo)
            ->select(DB::raw('AVG(TIMESTAMPDIFF(MINUTE, wm2.created_at, wm1.created_at)) as avg_time'))
            ->value('avg_time') ?? 0;

        $previousAvgResponseTime = DB::table('whatsapp_messages as wm1')
            ->join('whatsapp_messages as wm2', function($join) {
                $join->on('wm1.contact_id', '=', 'wm2.contact_id')
                    ->where('wm2.created_at', '<', DB::raw('wm1.created_at'))
                    ->where('wm2.sender_type', '=', 'client');
            })
            ->where('wm1.sender_type', 'system')
            ->whereBetween('wm1.created_at', [$sixtyDaysAgo, $thirtyDaysAgo])
            ->select(DB::raw('AVG(TIMESTAMPDIFF(MINUTE, wm2.created_at, wm1.created_at)) as avg_time'))
            ->value('avg_time') ?? 0;

        $responseTimeGrowth = $previousAvgResponseTime > 0
            ? (($avgResponseTime - $previousAvgResponseTime) / $previousAvgResponseTime) * 100
            : 0;

        // Clientes activos (contactos únicos con mensajes en los últimos 30 días)
        $activeClients = DB::table('whatsapp_messages')
            ->where('created_at', '>=', $thirtyDaysAgo)
            ->distinct('contact_id')
            ->count('contact_id');
        $previousActiveClients = DB::table('whatsapp_messages')
            ->whereBetween('created_at', [$sixtyDaysAgo, $thirtyDaysAgo])
            ->distinct('contact_id')
            ->count('contact_id');
        $activeClientsGrowth = $previousActiveClients > 0
            ? (($activeClients - $previousActiveClients) / $previousActiveClients) * 100
            : 0;

        // Mensajes con botones
        $buttonMessages = WhatsappMessage::where('type', 'button')
            ->where('created_at', '>=', $thirtyDaysAgo)
            ->count();
        $totalMessagesLastMonth = WhatsappMessage::where('created_at', '>=', $thirtyDaysAgo)->count();
        $buttonMessagesRate = $totalMessagesLastMonth > 0 ? ($buttonMessages / $totalMessagesLastMonth) * 100 : 0;

        $previousButtonMessages = WhatsappMessage::where('type', 'button')
            ->whereBetween('created_at', [$sixtyDaysAgo, $thirtyDaysAgo])
            ->count();
        $previousTotalMessages = WhatsappMessage::whereBetween('created_at', [$sixtyDaysAgo, $thirtyDaysAgo])->count();
        $previousButtonRate = $previousTotalMessages > 0 ? ($previousButtonMessages / $previousTotalMessages) * 100 : 0;
        $buttonMessagesGrowth = $previousButtonRate > 0
            ? (($buttonMessagesRate - $previousButtonRate) / $previousButtonRate) * 100
            : 0;

        // Tasa de interacción
        $interactions = WhatsappMessage::where('sender_type', 'client')
            ->where('created_at', '>=', $thirtyDaysAgo)
            ->count();
        $totalOutbound = WhatsappMessage::where('sender_type', 'system')
            ->where('created_at', '>=', $thirtyDaysAgo)
            ->count();
        $interactionRate = $totalOutbound > 0 ? ($interactions / $totalOutbound) * 100 : 0;

        $previousInteractions = WhatsappMessage::where('sender_type', 'client')
            ->whereBetween('created_at', [$sixtyDaysAgo, $thirtyDaysAgo])
            ->count();
        $previousOutbound = WhatsappMessage::where('sender_type', 'system')
            ->whereBetween('created_at', [$sixtyDaysAgo, $thirtyDaysAgo])
            ->count();
        $previousInteractionRate = $previousOutbound > 0 ? ($previousInteractions / $previousOutbound) * 100 : 0;
        $interactionRateGrowth = $previousInteractionRate > 0
            ? (($interactionRate - $previousInteractionRate) / $previousInteractionRate) * 100
            : 0;

        // Datos para gráficos
        $messagesData = WhatsappMessage::select(
            DB::raw('DATE(created_at) as date'),
            DB::raw('COUNT(CASE WHEN sender_type = "system" THEN 1 END) as sent'),
            DB::raw('COUNT(CASE WHEN sender_type = "client" THEN 1 END) as received')
        )
        ->where('created_at', '>=', $thirtyDaysAgo)
        ->groupBy('date')
        ->orderBy('date')
        ->get();

        // Tiempo de respuesta por día usando subconsulta
        $responseTimeData = DB::table('whatsapp_messages as wm1')
            ->join('whatsapp_messages as wm2', function($join) {
                $join->on('wm1.contact_id', '=', 'wm2.contact_id')
                    ->where('wm2.created_at', '<', DB::raw('wm1.created_at'))
                    ->where('wm2.sender_type', '=', 'client');
            })
            ->where('wm1.sender_type', 'system')
            ->where('wm1.created_at', '>=', $thirtyDaysAgo)
            ->select(
                DB::raw('DATE(wm1.created_at) as date'),
                DB::raw('AVG(TIMESTAMPDIFF(MINUTE, wm2.created_at, wm1.created_at)) as avg_time')
            )
            ->groupBy('date')
            ->orderBy('date')
            ->get();

        // Temas más frecuentes
        $topTopics = WhatsappMessage::select('type', DB::raw('COUNT(*) as count'))
            ->whereNotNull('type')
            ->where('created_at', '>=', $thirtyDaysAgo)
            ->groupBy('type')
            ->orderByDesc('count')
            ->limit(5)
            ->get()
            ->map(function ($item) {
                return [
                    'name' => $item->type,
                    'count' => $item->count
                ];
            });

        // Pedidos recientes (carritos completados)
        $orders = \App\Models\WhatsappCart::with(['items', 'contact'])
           // ->where('status', 'completed')
            ->latest()
            ->limit(5)
            ->get();

        // Mensajes recientes
        $messages = WhatsappMessage::with('contact')
            ->latest()
            ->limit(5)
            ->get();

        // Clientes nuevos este mes
        $newClientsThisMonth = DB::table('whatsapp_contacts')
            ->whereMonth('created_at', $now->month)
            ->whereYear('created_at', $now->year)
            ->count();

        // Pedidos de este mes (carritos completados)
        $ordersThisMonth = DB::table('whatsapp_carts')
            //->where('status', 'completed')
            ->whereMonth('created_at', $now->month)
            ->whereYear('created_at', $now->year)
            ->count();

        // Productos más pedidos este mes (por nombre)
        $topProducts = DB::table('whatsapp_cart_items')
            ->whereMonth('created_at', $now->month)
            ->whereYear('created_at', $now->year)
            ->select('name', DB::raw('SUM(quantity) as total'))
            ->groupBy('name')
            ->orderByDesc('total')
            ->limit(5)
            ->get();

        // Mensajes por hora este mes
        $messagesByHour = DB::table('whatsapp_messages')
            ->whereMonth('created_at', $now->month)
            ->whereYear('created_at', $now->year)
            ->select(DB::raw('HOUR(created_at) as hour'), DB::raw('COUNT(*) as total'))
            ->groupBy('hour')
            ->orderBy('hour')
            ->get();

        // Opciones más consultadas este mes (por type)
        $topOptions = DB::table('whatsapp_messages')
            ->whereMonth('created_at', $now->month)
            ->whereYear('created_at', $now->year)
            ->whereNotNull('type')
            ->select('type', DB::raw('COUNT(*) as total'))
            ->groupBy('type')
            ->orderByDesc('total')
            ->limit(5)
            ->get();

        // Imágenes más enviadas este mes (por nombre si está en metadata, si no solo cantidad)
        $topImages = DB::table('whatsapp_messages')
            ->whereMonth('created_at', $now->month)
            ->whereYear('created_at', $now->year)
            ->where('type', 'image')
            ->select(DB::raw('COUNT(*) as total'))
            ->first();

        return view('admin.dashboard', compact(
            'totalMessages',
            'messageGrowth',
            'responseRate',
            'responseRateGrowth',
            'avgResponseTime',
            'responseTimeGrowth',
            'activeClients',
            'activeClientsGrowth',
            'buttonMessagesRate',
            'buttonMessagesGrowth',
            'interactionRate',
            'interactionRateGrowth',
            'messagesData',
            'responseTimeData',
            'topTopics',
            'orders',
            'messages',
            'newClientsThisMonth',
            'ordersThisMonth',
            'topProducts',
            'messagesByHour',
            'topOptions',
            'topImages'
        ));
    }
}
