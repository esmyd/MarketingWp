<?php

namespace App\Http\Controllers;

use App\Models\WhatsappCart;
use App\Models\WhatsappMessage;
use App\Models\WhatsappContact;
use App\Models\WhatsappConversation;
use Illuminate\Http\Request;

class AdminController extends Controller
{
    public function dashboard()
    {
        $orders = WhatsappCart::with(['items', 'contact'])->latest()->get();
        $messages = WhatsappMessage::with(['contact', 'conversation'])->latest()->get();

        return view('admin.dashboard', compact('orders', 'messages'));
    }

    public function orders()
    {
        $orders = WhatsappCart::with(['items', 'contact'])
            ->latest()
            ->paginate(10);

        return view('admin.orders', compact('orders'));
    }

    public function messages()
    {
        $messages = WhatsappMessage::with(['contact', 'conversation'])
            ->latest()
            ->paginate(20);

        return view('admin.messages', compact('messages'));
    }

    public function orderDetails($id)
    {
        $order = WhatsappCart::with(['items', 'contact'])->findOrFail($id);
        return response()->json($order);
    }

    public function chats()
    {
        // Obtener contactos que tengan mensajes usando consultas directas
        $contacts = \App\Models\WhatsappContact::whereIn('id', function($query) {
            $query->select('contact_id')->from('whatsapp_messages')->distinct();
        })->get();
        // Contar mensajes por contacto y obtener último mensaje del cliente
        foreach ($contacts as $contact) {
            $contact->messages_count = \App\Models\WhatsappMessage::where('contact_id', $contact->id)->count();
            $lastClientMsg = \App\Models\WhatsappMessage::where('contact_id', $contact->id)
                ->where('sender_type', 'client')
                ->orderByDesc('created_at')
                ->first();
            $contact->last_client_message = $lastClientMsg ? $lastClientMsg->content : null;
        }
        // Si hay al menos un contacto, redirigir al primer chat
        if ($contacts->count() > 0) {
            return redirect()->route('admin.chat', $contacts->first()->id);
        }
        // Si no hay contactos, mostrar la vista original
        return view('admin.chats', compact('contacts'));
    }

    public function chat($contactId)
    {
        $contacts = \App\Models\WhatsappContact::whereIn('id', function($query) {
            $query->select('contact_id')->from('whatsapp_messages')->distinct();
        })->get();
        // Contar mensajes por contacto y obtener último mensaje del cliente
        foreach ($contacts as $contactItem) {
            $contactItem->messages_count = \App\Models\WhatsappMessage::where('contact_id', $contactItem->id)->count();
            $lastClientMsg = \App\Models\WhatsappMessage::where('contact_id', $contactItem->id)
                ->where('sender_type', 'client')
                ->orderByDesc('created_at')
                ->first();
            $contactItem->last_client_message = $lastClientMsg ? $lastClientMsg->content : null;
        }
        $contact = \App\Models\WhatsappContact::findOrFail($contactId);
        $messages = \App\Models\WhatsappMessage::where('contact_id', $contactId)->orderBy('created_at')->get();
        return view('admin.chat', compact('contacts', 'contact', 'messages'));
    }

    public function updateOrderStatus(Request $request, $id)
    {
        $order = \App\Models\WhatsappCart::findOrFail($id);
        $order->status = $request->input('status');
        $order->save();
        return response()->json(['success' => true]);
    }

    public function contactDetails($id)
    {
        $contact = \App\Models\WhatsappContact::findOrFail($id);
        return response()->json($contact);
    }
}
